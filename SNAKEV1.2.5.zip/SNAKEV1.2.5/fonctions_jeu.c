#include "fct_types.h"
#include "fct_menu.h"
#include "fct_pause.h"
#include "fct_perdu.h"
#include "fct_sauvegarde.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

int buffer_direction[3];
int taille_buffer = 0;


/*Charge et vérifie l'existance de tous les fichiers nécessaires au bon fonctionnement du jeu avant de les fermer*/
void test_toutes_les_images(){
    MLV_Image* img;
    int i;
    char fichiers[9][40] = {
        "assets/random.png", 
        "assets/wagon.png", 
        "assets/wagon_cote.png",
        "assets/locomotive_h.png", 
        "assets/locomotive_d.png", 
        "assets/locomotive_b.png", 
        "assets/locomotive_g.png",
        "assets/charbon.png", 
        "assets/cactus.png"
    };

    for(i = 0; i < 9; i++){
        img = MLV_load_image(fichiers[i]);
        if(!img){
            printf("Erreur fatale : Image manquante -> %s\n", fichiers[i]);
            exit(EXIT_FAILURE);
        }
        MLV_free_image(img);
    }
}
/*A chaque tour de boucle, permet de mettre a jour les coordonnees de la liste des positions du train*/
void tenir_a_j_liste(int coordonnees[361][2], int xtete, int ytete, int longueur){
    int i;
    for ( i = longueur ; i > 0 ; i-- ){
        coordonnees[i][0] = coordonnees[i-1][0];
        coordonnees[i][1] = coordonnees[i-1][1];
    }
    coordonnees[0][0] = xtete;
    coordonnees[0][1] = ytete;
}
/*Permet d'ajouter 2 valeurs x et y à la fin d'une liste de taille longueur*/
void ajouter_liste(int coordonnees[361][2], int x, int y, int longueur){
    coordonnees[longueur-1][0] = x;
    coordonnees[longueur-1][1] = y;
}
/*retourne la couleur d'une case de coordonnees x,y*/
MLV_Color get_couleur_case(int x, int y){
    if ( (x+y) % 2 == 0 ) return MLV_COLOR_PERU;
    else return MLV_COLOR_SANDY_BROWN;
}
/*affiche une image en traduisant les coordonnees x, y donnes en pixels pour que la fonction de MLV puisse afficehr correctement*/
void afficher_image(MLV_Image* image, int x, int y, int hauteur){
    int taille_case;
    if (!image){
        exit(EXIT_FAILURE);
    }
    taille_case = hauteur / taille_max;
    MLV_draw_image(image, x*taille_case, y*taille_case);
}
/*Fait spawn un bonus sur une case libre*/
void spawn_random(cases plateau[taille_max][taille_max], int hauteur){
    int i, j, bonus;
    
    MLV_Color couleur;
    MLV_Image* image = MLV_load_image("assets/random.png");
    for ( i = 0 ; i < taille_max ; i++ ){
        for ( j = 0 ; j < taille_max ; j++ ){/*efface un autre bonus potentiel*/
            if ( plateau[i][j].compteur < -1 && plateau[i][j].compteur != -10 ){
                plateau[i][j].compteur = 0;
                couleur = get_couleur_case(i,j);
                affichage_jeu( i, j, hauteur, couleur, 1 );
            }
            
        }
    }
    do {/*Cherche des coordonnes valides*/
        i = rand()%taille_max;
        j = rand()%taille_max;
    }
    while (plateau[i][j].compteur != 0);
    bonus = ( rand()%5 ) + 2;
    plateau[i][j].compteur -= bonus;
    afficher_image( image, i, j, hauteur);
    MLV_free_image(image);
}
/*on redessine tout car il y a trop de paramètres à prendre en compte sinon, ca rend plus propre*/
void redessiner_arriere_plan(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur) {
    int i, j, k;
    int est_dans_serpent;
    MLV_Color couleur;

    MLV_Image* img_pomme = MLV_load_image("assets/charbon.png");
    MLV_Image* img_cactus = MLV_load_image("assets/cactus.png");
    MLV_Image* img_random = MLV_load_image("assets/random.png");
    MLV_Image* wagon = MLV_load_image("assets/wagon.png");
    MLV_Image* wagon_c = MLV_load_image("assets/wagon_cote.png");

    for (i = 0; i < taille_max; i++) {
        for (j = 0; j < taille_max; j++) {
            /* On dessine le damier */
            couleur = get_couleur_case(i, j);
            affichage_jeu(i, j, hauteur, couleur, 1);

            /*On dessine les images */
            if (plateau[i][j].compteur == -1) 
                afficher_image(img_pomme, i, j, hauteur);
            else if (plateau[i][j].compteur == -10) 
                afficher_image(img_cactus, i, j, hauteur);
            else if (plateau[i][j].compteur < -1) 
                afficher_image(img_random, i, j, hauteur);
            
            /* 3. On dessine les wagons détachés sur le terrain */
            else if (plateau[i][j].compteur > 0) {
                
                est_dans_serpent = 0;
                /* On vérifie si la case fait partie du serpent ou non*/
                for(k = 0; k < longueur; k++) {
                    if(coordonnees[k][0] == i && coordonnees[k][1] == j) {
                        est_dans_serpent = 1;
                        break;
                    }
                }

                /* Si c'est un wagon mais qu'il n'est pas dans le serpent actif, on l'affiche */
                if (est_dans_serpent == 0) {
                    if (plateau[i][j].direction % 2 == 0) 
                        afficher_image(wagon_c, i, j, hauteur);
                    else 
                        afficher_image(wagon, i, j, hauteur);
                }
            }
        }
    }

    MLV_free_image(img_pomme);
    MLV_free_image(img_cactus);
    MLV_free_image(img_random);
    MLV_free_image(wagon);
    MLV_free_image(wagon_c);
}


void affichage_train(cases plateau[taille_max][taille_max], int coordonnees[361][2], int *longueur, int hauteur, float pourcentage, int direction_tete, int anc_queue_x, int anc_queue_y){
    int i;
    int taille_case = hauteur / taille_max;
    
    int dest_x, dest_y; 
    int start_x, start_y;
    float pixel_x, pixel_y;
    
    MLV_Image* image_train_actuelle;
    MLV_Image* wagon = MLV_load_image("assets/wagon.png");
    MLV_Image* wagon_c = MLV_load_image("assets/wagon_cote.png");
    MLV_Image* loc_h = MLV_load_image("assets/locomotive_h.png");
    MLV_Image* loc_d = MLV_load_image("assets/locomotive_d.png");
    MLV_Image* loc_b = MLV_load_image("assets/locomotive_b.png");
    MLV_Image* loc_g = MLV_load_image("assets/locomotive_g.png");

    
    redessiner_arriere_plan(plateau, coordonnees, *longueur, hauteur);
    /*On efface tout*/

    
    for (i = 0; i < *longueur; i++) {
       
        dest_x = coordonnees[i][0];
        dest_y = coordonnees[i][1];

        if (i < *longueur - 1) {
            start_x = coordonnees[i+1][0];
            start_y = coordonnees[i+1][1];
        } else {
            start_x = anc_queue_x;
            start_y = anc_queue_y;
        }

        if (abs(dest_x - start_x) > 1 || abs(dest_y - start_y) > 1) {
            /*Si on traverse un mur on affiche directement car on ne peut diviser une image*/
             pixel_x = dest_x * taille_case;
             pixel_y = dest_y * taille_case;
        } else {
            /*Sinon on y applique un décalage*/
             pixel_x = (start_x + (float)(dest_x - start_x) * pourcentage) * taille_case;
             pixel_y = (start_y + (float)(dest_y - start_y) * pourcentage) * taille_case;
        }

        if (i == 0) {
             switch(direction_tete) {
                case 1: image_train_actuelle = loc_h; break;
                case 2: image_train_actuelle = loc_d; break;
                case 3: image_train_actuelle = loc_b; break;
                case 4: image_train_actuelle = loc_g; break;
                default: image_train_actuelle = loc_h; break;
            }
             /*On choisit la bonne image*/
        } else {
            if (plateau[dest_x][dest_y].direction % 2 == 0) image_train_actuelle = wagon_c;
            else image_train_actuelle = wagon;
        }

        MLV_draw_image(image_train_actuelle, (int)pixel_x, (int)pixel_y);
    }
    
    MLV_actualise_window();
    
    MLV_free_image(wagon); MLV_free_image(wagon_c);
    MLV_free_image(loc_h); MLV_free_image(loc_d);
    MLV_free_image(loc_b); MLV_free_image(loc_g);
}


/*dessine une case de la couleur voulue aux coordonnées voulues*/
void affichage_jeu(int x, int y, int hauteur, MLV_Color couleur, int transformer_x_y){
    int taille_case = hauteur / taille_max;
    if (transformer_x_y == 1) {
        MLV_draw_filled_rectangle(x * taille_case, y * taille_case, taille_case, taille_case, couleur);
    } else {
        MLV_draw_filled_rectangle(x, y, taille_case, taille_case, couleur);
    }
}
/*fait apparaitre une pomme à des coordonnees valides*/
void spawn_pomme(cases plateau[taille_max][taille_max], int hauteur){
    int xpomme, ypomme;
    MLV_Image* image = MLV_load_image("assets/charbon.png");
    do{
        xpomme = rand() % taille_max;
        ypomme = rand() % taille_max;
    } while (plateau[xpomme][ypomme].compteur != 0);
    
    plateau[xpomme][ypomme].compteur = -1;
    afficher_image(image, xpomme, ypomme, hauteur);
    MLV_free_image(image);
}
/*initialise les cases du plateau à 0 et suivznt si la partie est issue d'une sauvegarde peut set up les variables de jeu*/
void init_plat(cases plateau[taille_max][taille_max], int *xtete, int *ytete, int save){
    int i, j;
    for (i = 0; i < taille_max; i++){
        for (j = 0; j < taille_max; j++){
            plateau[i][j].serpent = 0;
            plateau[i][j].compteur = 0;
            plateau[i][j].direction = 0;
        }
    }
    if ( save == 0 ) {
        *xtete = 9;
        *ytete = 9;
        plateau[9][9].serpent = 1;
        plateau[9][9].compteur = 1;
        plateau[9][9].direction = 1;
    }
}
/*Affiche le jeu complet suite à une pause, un chargement de sauvegarde ou simplement un debut de partie. Peut faire spawn une pomme suivant l'argument pomme*/
void affichage_initial(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, int pomme){
    int i, j, k, present;
    /* On récupère la position actuelle de la queue pour l'envoyer à affichage_train */
    int queue_x = coordonnees[longueur-1][0];
    int queue_y = coordonnees[longueur-1][1];
    /* On récupère la direction de la tête pour l'affichage correct de la locomotive */
    int dir_tete = plateau[coordonnees[0][0]][coordonnees[0][1]].direction;
    if (dir_tete == 0) dir_tete = 1; /* Sécurité si direction pas encore définie */

    MLV_Image* pomme_image = MLV_load_image("assets/charbon.png");
    MLV_Image* cactus_image = MLV_load_image("assets/cactus.png");
    MLV_Image* random_image = MLV_load_image("assets/random.png");
    MLV_Image* wagon = MLV_load_image("assets/wagon.png");
    MLV_Image* wagon_cote = MLV_load_image("assets/wagon_cote.png");

    MLV_clear_window(MLV_COLOR_BLACK);

    /* Note : Cette boucle affiche les wagons "perdus" (détachés du train principal) */
    /* Le fond sera redessiné par affichage_train juste après, mais ce n'est pas grave */
    for (i = 0; i < taille_max; i++){
        for (j = 0; j < taille_max; j++){
            
            /* On ne dessine ici que les wagons perdus (compteur > 0 mais pas dans la liste) */
            if ( plateau[i][j].compteur > 0 ){
                present = 0;
                for (k = 0; k < longueur; k++){
                    if (coordonnees[k][0] == i && coordonnees[k][1] == j){
                        present = 1;
                    }
                }
                if (!present){
                    /* C'est un wagon perdu, on le dessine manuellement */
                    /* On dessine d'abord le sol dessous pour que ce soit propre */
                    if ((i + j) % 2 == 0) affichage_jeu(i, j, hauteur, MLV_COLOR_PERU, 1);
                    else affichage_jeu(i, j, hauteur, MLV_COLOR_SANDY_BROWN, 1);

                    if (plateau[i][j].direction % 2 == 0) afficher_image(wagon_cote, i, j, hauteur);
                    else afficher_image(wagon, i, j, hauteur);
                }
            }
        }
    }

    if ( pomme == 1) spawn_pomme(plateau, hauteur);

    /* --- CORRECTION ICI --- */
    /* On passe 0.0 en pourcentage (pas de mouvement) */
    /* On passe queue_x et queue_y comme "ancienne queue" (puisque ça ne bouge pas) */
    affichage_train(plateau, coordonnees, &longueur, hauteur, dir_tete, 0, queue_x, queue_y);
    
    MLV_actualise_window();
    MLV_wait_milliseconds(150);
    
    MLV_free_image(pomme_image);
    MLV_free_image(cactus_image);
    MLV_free_image(random_image);
    MLV_free_image(wagon);
    MLV_free_image(wagon_cote);
}


/*avance la tete du train, pour les cases suivantes elles prendront toute la valeur de la case les précédant*/
void avancer_tete(cases plateau[taille_max][taille_max], int xtete, int ytete, int longueur, int direction){
    plateau[xtete][ytete].serpent = 1;
    plateau[xtete][ytete].compteur = longueur;
    plateau[xtete][ytete].direction = direction;
}
/*Permet de charger les 10 meilleurs scores si le fichier records existe*/
int get_scores(int meilleur[taille_meilleur]) {
  FILE* records = fopen("records.txt", "r");
  int i;
  int ret = 0;
  if (records == NULL) {
    return 1;
  }
    

  for (i = 0; i < 10; i++) {
    if (fscanf(records, "%d", &meilleur[i]) != 1) {
      ret = 1;
    }
  }
    
  fclose(records);
  return ret;
}
/*Sauvegarde les 10 meileurs scores suite à la partie*/
void ecrire_res(int meilleur[taille_meilleur]) {
  FILE* records = fopen("records.txt", "w");
  int i, derniere_dir;
  for ( i = 0; i < 10; i++) {
    fprintf(records, "%d\n", meilleur[i]);
  }
    
  fclose(records);
}
/*Ajoute à la liste des directions futures la dernière direction entrée, sauf si le buffer a deja 3 valeurs, si cette direction est l'opposée de la dernière entrée ou la même*/
void ajouter_au_buffer(int nouvelle_dir, int direction_actuelle) {
    int derniere_dir = 0;
    if (taille_buffer >= 3) return;
    if (taille_buffer > 0) derniere_dir = buffer_direction[taille_buffer - 1];
    else derniere_dir = direction_actuelle;

    if (derniere_dir == 1 && nouvelle_dir == 3) return;
    if (derniere_dir == 3 && nouvelle_dir == 1) return;
    if (derniere_dir == 2 && nouvelle_dir == 4) return;
    if (derniere_dir == 4 && nouvelle_dir == 2) return;
    if (derniere_dir == nouvelle_dir) return;

    buffer_direction[taille_buffer] = nouvelle_dir;
    taille_buffer++;
}
/*lit la dernière valeur du buffer de directions afin d'actualiser_direction_depuis_buffer*/
void actualiser_direction_depuis_buffer(int *direction) {
    int i;
    if (taille_buffer > 0) {
        *direction = buffer_direction[0];
        for(i = 0; i < taille_buffer - 1; i++){
            buffer_direction[i] = buffer_direction[i+1];
        }
        taille_buffer--;
    }
}
/*Fonction intermédiaire, permet d'effectuer l'attente afin que le jeu ne file pas à toute vitesse, calcule le chrono, initialise la pause et donc une potentielle sauvegarde, actualise les directions et enregistre la/les nouvelle(s), permet les affichages intermédiaires nécessaire à la fluidité des déplacements*/
int gestion_controles(cases plateau[taille_max][taille_max], int coordonnees[361][2], int *longueur, int hauteur, int direction_actuelle, int num_sauvegarde, int nb_pommes, float *chrono, float *temps_en_moins, float base, int score, float coef, int bonus) {
    
    MLV_Event event;
    MLV_Keyboard_button touche;
    MLV_Button_state etat;
    int quitter_pause = 0;
    int quit_global = 1; /* 1 = continue, 0 = quitte le jeu */
    float debut_pause;

    /* On récupère l'évènement */
    event = MLV_get_event(&touche, NULL, NULL, NULL, NULL, NULL, NULL, NULL, &etat);

    if (event == MLV_KEY && etat == MLV_PRESSED) {
        int nouv = 0;
        switch(touche){
            case MLV_KEYBOARD_UP : nouv = 1; break;
            case MLV_KEYBOARD_RIGHT : nouv = 2; break;
            case MLV_KEYBOARD_DOWN : nouv = 3; break;
            case MLV_KEYBOARD_LEFT : nouv = 4; break;
            case MLV_KEYBOARD_ESCAPE : 
                /* Gestion de la pause*/
                debut_pause = MLV_get_time() * 0.001;
                quitter_pause = boucle_pause(plateau, *longueur, coordonnees, num_sauvegarde, nb_pommes, *chrono, score, coef, bonus);
                
                /* On réaffiche le plateau après la pause car l'écran a changé*/
                affichage_initial(plateau, coordonnees, *longueur, hauteur, 0);
                
                if (quitter_pause == 1){
                    quit_global = 0; /*Boutton quitté pressé en pause*/
                } else {
                    /* On ajoute le temps passé en pause au temps en moins pour corriger le chrono */
                    *temps_en_moins += (MLV_get_time() * 0.001) - debut_pause;
                }
                break;
            default: break;
        }
        if (nouv != 0) ajouter_au_buffer(nouv, direction_actuelle);
    }

    return quit_global;
}

/*permet de connaitre la future position de la tete en fonction de la direction*/
void calculer_position_future(int xtete, int ytete, int direction, int *futur_x, int *futur_y){
    *futur_x = xtete;
    *futur_y = ytete;
    switch(direction){
        case 1: (*futur_y)--; if(*futur_y < 0) *futur_y = taille_max - 1; break;
        case 2: (*futur_x) = (*futur_x + 1) % taille_max; break;
        case 3: (*futur_y) = (*futur_y + 1) % taille_max; break;
        case 4: (*futur_x)--; if(*futur_x < 0) *futur_x = taille_max - 1; break;
    }
}
/*Fait apparaitre un cactus sur une case valide*/
void spawn_mur(cases plateau[taille_max][taille_max], int hauteur){
    int i, j;
    MLV_Image* image = MLV_load_image("assets/cactus.png");
    do {
        i = rand()%taille_max;
        j = rand()%taille_max;
    }
    while (plateau[i][j].compteur != 0);
    plateau[i][j].compteur = -10 ;
    afficher_image(image, i, j, hauteur);
    MLV_free_image(image);        
}
/*devait initialement recoler les wagons perdus au train mais finalement les efface seulement*/
void recoler_tout(cases plateau[taille_max][taille_max], int longueur, int coordonnees[361][2], int hauteur){
    int i, j, k;
    int trouve;
    MLV_Color couleur;

    for ( i = 0; i < taille_max; i++ ){
        for ( j = 0 ; j < taille_max; j++ ){
            if ( plateau[i][j].compteur > 0 ){
                trouve = 0;
                k = 0;
                while ( k < longueur && trouve == 0 ){
                    if ( coordonnees[k][0] == i && coordonnees[k][1] == j ){
                        trouve = 1;/*Verifie que les wagons ne fassent pas partie du train*/
                    }
                    k++;
                }

                if ( trouve == 0 ){
                    plateau[i][j].compteur = 0;
                    plateau[i][j].serpent = 0;
                    couleur = get_couleur_case(i, j);
                    affichage_jeu(i, j, hauteur, couleur, 1);
                }
            }
        }
    }
}
/*Verifie la prochaine interaction du train */
void verifier_interaction_case(cases plateau[taille_max][taille_max], int futur_x, int futur_y, int hauteur, int *pafini, int *a_mange, int *nbpomme, int *longueur, float *coef, int *divise, int coordonnees[361][2], int *bonus){
    
    switch (plateau[futur_x][futur_y].compteur){
    case 0 : break;
    case -1 :
        *a_mange = 1;
        *nbpomme += 1;        
        spawn_pomme(plateau, hauteur);
        break;/*pomme mangee*/
    case -2 : *bonus+= *nbpomme; break;/*Ajoute à bonus le nb de pommes pour augmenter le score*/
    case -3 : *divise = 1; break;/*supprime la moitie du train*/
    case -4 : spawn_mur(plateau, hauteur);break;/*fait apparaitre un cactus sur la map*/
    case -5 : *coef += 2.0 ; break;/*Augmente le malus du temps sur le score*/
    case -6 : recoler_tout(plateau, *longueur, coordonnees, hauteur); break;/*Supprime les wagons égarés*/
    case -10 : *divise = 2; break;/*détache la moitié du train*/
    default : *pafini = 0; break;
    }
}

/*deplace le serpent entier en utilisant les deux autre fonctions pour la tete et le corps*/
void deplacer_serpent(cases plateau[taille_max][taille_max], int coordonnees[361][2], int xtete, int ytete, int futur_x, int futur_y, int *longueur, int a_mange, int direction, int hauteur){
    int queue_x, queue_y;
    MLV_Color couleur_fond;


    if (a_mange == 0) {
        queue_x = coordonnees[*longueur-1][0];
        queue_y = coordonnees[*longueur-1][1];
        
        plateau[queue_x][queue_y].serpent = 0;
        plateau[queue_x][queue_y].compteur = 0;
        plateau[queue_x][queue_y].direction = 0;
        
        couleur_fond = get_couleur_case(queue_x, queue_y);
        affichage_jeu(queue_x, queue_y, hauteur, couleur_fond, 1);
    } else {
        (*longueur)++;
    }


    plateau[xtete][ytete].serpent = 0;

 
    tenir_a_j_liste(coordonnees, futur_x, futur_y, *longueur);
    avancer_tete(plateau, futur_x, futur_y, *longueur, direction);
}

/*range le score actuel dans une copie de la liste des scores afin de ne pas la modifier définitivement*/
void mettre_a_jour_scores(int score, int meilleur[taille_meilleur], int nouvelle_liste[taille_meilleur]) {
    int i = 0;
    int j = 0;
    int insere = 0;

    while (j < taille_meilleur) {
        if (insere == 0 && score > meilleur[i]) {
            nouvelle_liste[j] = score;
            insere = 1;
        } else {
            nouvelle_liste[j] = meilleur[i];
            i = i + 1;
        }
        j = j + 1;
    }
    
}


/*Gère l'utilisation de toutes les fonctions pour le bon déroulement du jeu*/
int main_jeu(int hauteur, int save){
    /* déclarations des variables au début */
    int lecture_save, i;
    int pafini = 1, quitter = 0, quit_jeu = 0, rejouer = 0;
    int direction = 1, attente = 130;
    int xtete, ytete, futur_x, futur_y;
    int longueur = 1, score = 0, nb_pommes = 0, a_mange = 0, pomme = 1, divise = 0;
    int bonus = 0;
    int compteur_random = 0;
    
    int anc_queue_x = 0, anc_queue_y = 0;
    int ancienne_longueur;

    int temps_debut_image;
    int temps_fin_image;
    int temps_passe;
    
    int dernier_mvt_temps, temps_actuel;
    
    float chrono = 0.0, temps_en_moins = 0.0, base = 0.0;
    float coef = 15.0, moyenne = 0.0;
    float pourcentage = 0.0;

    cases plateau[taille_max][taille_max];
    int coordonnees[361][2], nv_liste_scores[taille_meilleur];
    int meilleur[10];

    /* préparation du jeu */
    srand(time(NULL));
    test_toutes_les_images();

    init_plat(plateau, &xtete, &ytete, save);

    /* chargement de la sauvegarde ou nouvelle partie */
    if ( save != 0 ){
        lecture_save = lire_sauvegarde( plateau, &longueur, coordonnees, save, &nb_pommes, &base, &bonus, &coef, &bonus);
        pomme = 0;
        if ( lecture_save == 0 ) exit(EXIT_FAILURE);
        
        xtete = coordonnees[0][0];
        ytete = coordonnees[0][1];
        direction = plateau[xtete][ytete].direction;
        anc_queue_x = coordonnees[longueur-1][0];
        anc_queue_y = coordonnees[longueur-1][1];
    }
    else {
        ajouter_liste(coordonnees, xtete, ytete, longueur);
        anc_queue_x = xtete;
        anc_queue_y = ytete;
    }
    
    taille_buffer = 0;
    affichage_initial(plateau, coordonnees, longueur, hauteur, pomme);

    if (get_scores(meilleur)){
        for (i=0; i<10; i++) meilleur[i] = 0;
    }
    afficher_menu_cote(score, meilleur);
    
    temps_en_moins = MLV_get_time() * 0.001;
    dernier_mvt_temps = MLV_get_time();

    /* boucle principale :une image par tour */
    do {
        /*on regarde l'instant au début de l'image*/
        temps_debut_image = MLV_get_time();
        temps_actuel = temps_debut_image;
        
        /* calcul du décalage pour déplacement fluide*/
        pourcentage = (float)(temps_actuel - dernier_mvt_temps) / (float)attente;
        if (pourcentage > 1.0) pourcentage = 1.0;

        /* on affiche tout*/
        affichage_train(plateau, coordonnees, &longueur, hauteur, pourcentage, direction, anc_queue_x, anc_queue_y);
        
        afficher_menu_cote(score, nv_liste_scores);
        afficher_chrono(chrono);
        MLV_actualise_window();

        /*on vérifie si une touche est appuyée */
        quitter = gestion_controles(plateau, coordonnees, &longueur, hauteur, direction, save, nb_pommes, &chrono, &temps_en_moins, base, score, coef, bonus);

        if (quitter == 0) quit_jeu = 1; 
        else chrono = (MLV_get_time() * 0.001) - temps_en_moins + base;

        /* si il faut faire bouger le serpent */
        if (temps_actuel - dernier_mvt_temps >= attente && quitter != 0) {
            
            actualiser_direction_depuis_buffer(&direction);

            if (nb_pommes > 0) moyenne = chrono / nb_pommes;
            else moyenne = 0;
            
            /*on retient la position de la queue avant de bouger */
            anc_queue_x = coordonnees[longueur - 1][0];
            anc_queue_y = coordonnees[longueur - 1][1];

            calculer_position_future(xtete, ytete, direction, &futur_x, &futur_y);
            a_mange = 0;
            
            verifier_interaction_case(plateau, futur_x, futur_y, hauteur, &pafini, &a_mange, &nb_pommes, &longueur, &coef, &divise, coordonnees, &bonus);

            if (pafini) {
                /* gestion des bonus qui coupent le serpent*/
                if (divise > 0) {
                    ancienne_longueur = longueur;
                    longueur = longueur / 2;
                    
                    /* si bonus diviser, on efface les wagons coupés */
                    if (divise == 1) {
                        for(i = longueur; i < ancienne_longueur; i++) {
                            plateau[coordonnees[i][0]][coordonnees[i][1]].compteur = 0;
                            plateau[coordonnees[i][0]][coordonnees[i][1]].serpent = 0;
                        }
                    }
                    /* sinon si impact cactus on les laisse comme obstacles */
                    divise = 0;
                }

                deplacer_serpent(plateau, coordonnees, xtete, ytete, futur_x, futur_y, &longueur, a_mange, direction, hauteur);
                
                xtete = futur_x;
                ytete = futur_y;

                /* faire apparaitre un bonus de temps en temps */
                if (compteur_random == 100){
                    compteur_random = 0;
                    spawn_random(plateau, hauteur);
                } else {
                    compteur_random++;
                }
            }
            
            /* mise à jour du score */
            score = (nb_pommes * 100) - (coef * moyenne) + bonus;
            if ( score < 0 ) score = 0;
            
            mettre_a_jour_scores(score, meilleur, nv_liste_scores);
            dernier_mvt_temps = temps_actuel;
        }

        /* on regarde l'heure à la fin de l'image */
        temps_fin_image = MLV_get_time();

        /* on calcule combien de temps ça a pris */
        temps_passe = temps_fin_image - temps_debut_image;

        /*  on attend un peu si trop rapide, 17 affichages pour environ 60fps */
        if (temps_passe < 17) {
            MLV_wait_milliseconds( 17 - temps_passe );
        }

    } while (pafini && quitter);

    /* fin de partie */
    if (quit_jeu != 1){
        rejouer = boucle_perdu(&score);
        ecrire_res(nv_liste_scores);
        if (rejouer == 0) quit_jeu = 0;
        else quit_jeu = 1; 
    }
    
    return quit_jeu;
}