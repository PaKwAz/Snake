#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>
#include "fct_menu.h"
#include "fct_types.h"

/*Crée et affiche un bouton avec bordure et texte centré.*/
void creer_bouton(int x, int y, int width, int height, char* texte, 
                  MLV_Color couleur_fond, MLV_Color couleur_texte, MLV_Font* font) {
    MLV_draw_filled_rectangle(x, y, width, height, couleur_fond);
    
    /* Double texte pour effet de profondeur */
    MLV_draw_rectangle(x, y, width, height, MLV_rgba(101, 67, 33, 255));
    MLV_draw_rectangle(x+2, y+2, width-4, height-4, MLV_rgba(139, 90, 43, 255));
    
    /* centrer le texte */
    int text_width, text_height;
    MLV_get_size_of_text_with_font(texte, &text_width, &text_height, font);
    
    int text_x = x + (width - text_width) / 2;
    int text_y = y + (height - text_height) / 2;
    
    MLV_draw_text_with_font(text_x, text_y, texte, font, couleur_texte);
}

/*Affiche une animation visuelle lors du clic sur un bouton*/
void animation_clic_bouton(int x, int y, int width, int height, char* texte, MLV_Font* font) {
    creer_bouton(x, y, width, height, texte, MLV_rgba(255, 215, 0, 255), 
                 MLV_rgba(139, 69, 19, 255), font);
    
    MLV_actualise_window();
    MLV_wait_milliseconds(75);
}

/*Détecte si un clic de souris se trouve dans une zone*/

int clic_bouton(int bx, int by, int bw, int bh, int mx, int my) {
    return (mx >= bx && mx <= bx + bw &&
            my >= by && my <= by + bh);
}

/*Affiche menu principal avec titre, boutons et tableau de scores*/
void afficher_menu(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {
  MLV_Font* tscore = MLV_load_font("assets/ARCADE_N.TTF", 35);
  char* titre = "IRON SNAKE";
  char* createurs = "Mael & Martin";
  int titre_w, titre_h;
  int score_y;
  int meilleur[10];
  int i;
  
  /* Récupération des scores 0 si erreur */
  if (get_scores(meilleur)){
    for (i=0; i<10; i++) meilleur[i]=0;
  }

  MLV_draw_image(fond,0,0);
  
  /*----------------------------------TITRES & nom créateurs------------------------*/
  MLV_get_size_of_text_with_font(titre, &titre_w, &titre_h, font_titre);
    
  /* Effet de profondeur */
  MLV_draw_text_with_font((1500 - titre_w) / 2 + 3, 53, titre, font_titre, MLV_COLOR_BLACK);
  MLV_draw_text_with_font((1500 - titre_w) / 2, 50, titre, font_titre, MLV_rgba(255, 248, 220, 255));

  MLV_get_size_of_text_with_font(createurs, &titre_w, &titre_h, font_bouton);
  
  MLV_draw_text_with_font((1500 - titre_w) / 2 + 3, 953, createurs, font_bouton, MLV_COLOR_BLACK);
  MLV_draw_text_with_font((1500 - titre_w) / 2, 950, createurs, font_bouton, MLV_rgba(255, 248, 220, 255));
  

  /*----------------------------------SCORES------------------------*/
  creer_bouton(800, 250, 400, 580, "", MLV_rgba(184, 134, 11, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

  MLV_draw_text_with_font(825+3, 275, "Meilleurs", tscore, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(825, 275, "Meilleurs", tscore, MLV_rgba(139, 0, 0, 255));
  MLV_draw_text_with_font(825+3, 315, "scores :", tscore, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(825, 315, "scores :", tscore, MLV_rgba(139, 0, 0, 255));
  
  /* Affichage du top 10 avec espacement de 45px */
  score_y = 315;
  for (i=0; i<10; i++){
    score_y = score_y + 45;
    MLV_draw_adapted_text_box_with_font(825, score_y, "#%d:%d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, i+1, meilleur[i]);
  }
  
  /*----------------------------------BOUTONS------------------------*/
  creer_bouton(250, 250, 500, 100, "NOUVELLE PARTIE", 
	       MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
  creer_bouton(250, 370, 500, 100, "CONTINUER", 
	       MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
  creer_bouton(250, 490, 500, 100, "COMMANDES", 
	       MLV_rgba(218, 165, 32, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  
    creer_bouton(250, 610, 500, 100, "BONUS", 
	       MLV_rgba(184, 134, 11, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
  creer_bouton(250, 730, 500, 100, "QUITTER", 
	       MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  
  MLV_actualise_window();
  MLV_free_font(tscore);
}

/*Affiche le panneau latéral durant la partie, score actuel, top 3, chrono*/
void afficher_menu_cote(int score, int meilleur[taille_meilleur]) {
  MLV_Font* tscore = MLV_load_font("assets/ARCADE_N.TTF", 40);
  MLV_Font* echap = MLV_load_font("assets/ARCADE_N.TTF", 25);
  int tscore_w, tscore_h;
  int echap_w, echap_h;
  
  MLV_get_size_of_text_with_font("SCORE :", &tscore_w, &tscore_h, tscore);
  MLV_get_size_of_text_with_font("echap pour pause", &echap_w, &echap_h, echap);

  creer_bouton(1000, 10, 490, 978, "", MLV_rgba(184, 134, 11, 255), MLV_rgba(255, 248, 220, 255), echap);
    
  MLV_draw_text_with_font((1000 + (500 - tscore_w) / 2 -75)+3, 50, "Score :", tscore, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(1000 + (500 - tscore_w) / 2 -75, 50, "Score :", tscore, MLV_rgba(139, 0, 0, 255));
    
  MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 125, "%d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, score);

  MLV_draw_text_with_font((1000 + (500 - tscore_w) / 2 -75)+3, 225, "Meilleurs :", tscore, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(1000 + (500 - tscore_w) / 2 -75, 225, "Meilleurs :", tscore, MLV_rgba(139, 0, 0, 255));
     
  MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 300, "#1 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleur[0]);

  MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 350, "#2 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleur[1]);

  MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 400, "#3 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleur[2]);

  MLV_draw_text_with_font((1000 + (500 - tscore_w) / 2 -75)+3, 500, "Chrono :", tscore, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(1000 + (500 - tscore_w) / 2 -75, 500, "Chrono :", tscore, MLV_rgba(139, 0, 0, 255));

  MLV_draw_text_with_font(1000 + (500 - echap_w) / 2, 950, "echap pour pause", echap, MLV_rgba(255, 215, 0, 255));
  
  MLV_free_font(tscore);
  MLV_free_font(echap);
}

/*Met à jour l'affichage du chronomètre dans le panneau latéral.*/
void afficher_chrono(float chrono){
  int tscore_w, tscore_h;
    
  MLV_Font* tscore = MLV_load_font("assets/ARCADE_N.TTF", 40);

  MLV_get_size_of_text_with_font("SCORE :", &tscore_w, &tscore_h, tscore);

  MLV_draw_filled_rectangle(1000,550,350, 300, MLV_rgba(184, 134, 11, 255));
    
  MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 550, "%.2f", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, chrono);
  MLV_free_font(tscore);
}

/*Affiche un message d'erreur lorsqu'une sauvegarde est introuvable.*/
void afficher_erreur_sauvegarde(int y, MLV_Font* font_bouton){
  creer_bouton(500, y, 500, 100, "Inexistante", MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  MLV_actualise_window();
}

/* Affiche l'écran des sauvegardes */
void afficher_continuer(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {
    char* titre = "CHARGER";
    int titre_w, titre_h;

    MLV_draw_image(fond,0,0);
    MLV_get_size_of_text_with_font(titre, &titre_w, &titre_h, font_titre);
    
    MLV_draw_text_with_font((1500 - titre_w) / 2 + 3, 53, titre, font_titre, MLV_COLOR_BLACK);
    MLV_draw_text_with_font((1500 - titre_w) / 2, 50, titre, font_titre, MLV_rgba(255, 248, 220, 255));
    
    creer_bouton(500, 200, 500, 100, "Sauvegarde 1", 
                 MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(500, 350, 500, 100, "Sauvegarde 2", 
                 MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(500, 500, 500, 100, "Sauvegarde 3", 
                 MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

    creer_bouton(500, 650, 500, 100, "Sauvegarde 4", 
                 MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(1050, 850, 300, 90, "RETOUR", 
                 MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    MLV_actualise_window();
}

/*Boucle qui affiche le menu et qui gère les boutons*/
int boucle_menu(int width, int height) {
    int i = 1, test = 0;
    int mx, my;
    
    MLV_Image* fond = MLV_load_image("assets/fond.png");
    MLV_Image* commandes = MLV_load_image("assets/commandes.png");
    MLV_Image* fond_bonus = MLV_load_image("assets/fond_bonus.png");
    MLV_Font* font_titre = MLV_load_font("assets/ARCADE_N.TTF", 100);
    MLV_Font* font_bouton = MLV_load_font("assets/ARCADE_N.TTF", 20);
    
    /*Retourne -1 en cas d'erreur de chargement des assets, 0 sinon.*/
    if (!font_titre || !font_bouton || !fond || !commandes || !fond_bonus) {
      printf("Votre fichier assets est incomplet veuillez le vérifier avant de lancer le jeu. \n");
      i = 0;
      test = -1;
    }
    /*boucle qui s'arrête si i = 0*/
    while (i == 1) {
        afficher_menu(font_titre, font_bouton, fond);
        
        MLV_wait_mouse(&mx, &my);
	
        /*si la souris a cliqué sur ces coordonnées alors faire...*/
        if (clic_bouton(250, 370, 500, 100, mx, my)) {
            animation_clic_bouton(250, 370, 500, 100, "CONTINUER", font_bouton);
            if (boucle_continuer(width, height, font_titre, font_bouton, fond) == -1) {
                i = 0;
                test = -1;
            }
        }
        
        if (clic_bouton(250, 490, 500, 100, mx, my)) {
            animation_clic_bouton(250, 490, 500, 100, "COMMANDES", font_bouton);
            boucle_commandes(width, height, font_bouton, font_titre,  commandes);
        }

	if (clic_bouton(250, 610, 500, 100, mx, my)) {
            animation_clic_bouton(250, 610, 500, 100, "BONUS", font_bouton);
            boucle_bonus(width, height, font_bouton, font_titre, fond_bonus);
        }
        
        if (clic_bouton(250, 250, 500, 100, mx, my)) {
            animation_clic_bouton(250, 250, 500, 100, "NOUVELLE PARTIE", font_bouton);
            if (boucle_nouvelle(width, height, font_titre, font_bouton, fond) == -1) {
                i = 0;
                test = -1;
            }
        }
        
        if (clic_bouton(250, 730, 500, 100, mx, my)) {
            animation_clic_bouton(250, 730, 500, 100, "QUITTER", font_bouton);
            i = 0;
        }
    }
    
    MLV_free_font(font_titre);
    MLV_free_font(font_bouton);
    
    return test;
}

/*Boucle qui affiche les commandes et qui gère les boutons*/

void boucle_commandes(int width, int height, MLV_Font* font_bouton, MLV_Font* font_titre,  MLV_Image* commandes) {
  int i = 1;
  int mx, my;
    
  while (i == 1) {
    MLV_draw_image(commandes,0,0);
    
    MLV_draw_text_with_font(203, 203, "PAUSE", font_titre, MLV_COLOR_BLACK);
    MLV_draw_text_with_font(200, 200, "PAUSE", font_titre, MLV_rgba(255, 248, 220, 255));

    MLV_draw_text_with_font(853, 203, "BOUGER", font_titre, MLV_COLOR_BLACK);
    MLV_draw_text_with_font(850, 200, "BOUGER", font_titre, MLV_rgba(255, 248, 220, 255));
    
    creer_bouton(1050, 850, 300, 90, "RETOUR", MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    MLV_actualise_window();
    
    MLV_wait_mouse(&mx, &my);
        
    if (clic_bouton(1050, 850, 300, 90, mx, my)) {
      animation_clic_bouton(1050, 850, 300, 90, "RETOUR", font_bouton);
      i = 0;
    }
  }
}

/*Boucle qui affiche les bonus et qui gère les boutons*/
void boucle_bonus(int width, int height, MLV_Font* font_bouton, MLV_Font* font_titre,  MLV_Image* fond_bonus) {
  int i = 1;
  int mx, my;
    
  while (i == 1) {
    MLV_draw_image(fond_bonus,0,0);

    MLV_draw_text_with_font(503, 403, "Bonus ou Malus...", font_bouton, MLV_COLOR_BLACK);
    MLV_draw_text_with_font(500, 400, "Bonus ou Malus...", font_bouton, MLV_rgba(255, 248, 220, 255));

    MLV_draw_text_with_font(503, 603, "Decroche les wagons si pris.", font_bouton, MLV_COLOR_BLACK);
    MLV_draw_text_with_font(500, 600, "Decroche les wagons si pris.", font_bouton, MLV_rgba(255, 248, 220, 255));

    MLV_draw_text_with_font(503, 653, "Un bonus permet de les faire disparaitre!", font_bouton, MLV_COLOR_BLACK);
    MLV_draw_text_with_font(500, 650, "Un bonus permet de les faire disparaitre!", font_bouton, MLV_rgba(255, 248, 220, 255));
    
    creer_bouton(1050, 850, 300, 90, "RETOUR", MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    MLV_actualise_window();
    MLV_wait_mouse(&mx, &my);
      
    if (clic_bouton(1050, 850, 300, 90, mx, my)) {
      animation_clic_bouton(1050, 850, 300, 90, "RETOUR", font_bouton);
      i = 0;
    }
  }
}

/* Boucle qui affiche les 4 sauvegardes et qui les lances si cliqué*/
int boucle_continuer(int width, int height, MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {
  int i = 1, j=0, test = 0;
  int mx, my;
  FILE* save;
  
  while (i == 1) {
    afficher_continuer(font_titre, font_bouton, fond);
        
    MLV_wait_mouse(&mx, &my);
        
    if (clic_bouton(1050, 850, 300, 90, mx, my)) {
      animation_clic_bouton(1050, 850, 300, 90, "RETOUR", font_bouton);
      i = 0;
    }
        
    /* Tentative de chargement de la sauvegarde 1 */
    if (clic_bouton(500, 200, 500, 100, mx, my)) {
      animation_clic_bouton(500, 200, 500, 100, "Sauvegarde 1", font_bouton);
      save = fopen("save1.txt", "r");
      if (save){
	while (j == 0) {
	  j  = main_jeu(1000, 1);
	}
	i=0;
      } else {
	afficher_erreur_sauvegarde(200, font_bouton);
	MLV_wait_seconds(2);
      }
    }
        
    /* Tentative de chargement de la sauvegarde 2 */
    if (clic_bouton(500, 350, 500, 100, mx, my)) {
      animation_clic_bouton(500, 350, 500, 100, "Sauvegarde 2", font_bouton);
      save = fopen("save2.txt", "r");
      if (save){
	while (j == 0) {
	  j  = main_jeu(1000, 2);
	}
	i=0;
      } else {
	afficher_erreur_sauvegarde(350, font_bouton);
	MLV_wait_seconds(2);
      }
    }
        
    /* Tentative de chargement de la sauvegarde 3 */
    if (clic_bouton(500, 500, 500, 100, mx, my)) {
      animation_clic_bouton(500, 500, 500, 100, "Sauvegarde 3", font_bouton);
      save = fopen("save3.txt", "r");
      if (save){
	while (j == 0) {
	  j  = main_jeu(1000, 3);
	}
	i=0;
      } else {
	afficher_erreur_sauvegarde(500, font_bouton);
	MLV_wait_seconds(2);
      }
    }

    /* Tentative de chargement de la sauvegarde 4 */
    if (clic_bouton(500, 650, 500, 100, mx, my)) {
      animation_clic_bouton(500, 650, 500, 100, "Sauvegarde 4", font_bouton);
      save = fopen("save4.txt", "r");
      if (save){
	while (j == 0) {
	  j  = main_jeu(1000, 4);
	}
	i=0;
      } else {
	afficher_erreur_sauvegarde(650, font_bouton);
	MLV_wait_seconds(2);
      }
    }
  }
  return test;
}

/*Lance une nouvelle partie*/
int boucle_nouvelle(int width, int height, MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {
  int i = 0, test = 0;
  while (i == 0) {
    i = main_jeu(1000, 0); /*0 comme paramêtre car pas de sauvegarde*/
  }
    
  return test;
}
