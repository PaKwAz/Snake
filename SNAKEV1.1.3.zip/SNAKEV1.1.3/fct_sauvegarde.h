#ifndef _FCT_SAVE_H_
#define _FCT_SAVE_H_

#include "fct_types.h"

void get_pomme(cases plateau[taille_max][taille_max], int * xpomme, int *ypomme);

int lire_sauvegarde(cases plateau[taille_max][taille_max], int *longueur, int coordonnees [361][2], int num_sauvegarde);

void sauvegarder(cases plateau[taille_max][taille_max], int longueur, int coordonnees [361][2], int num_sauvegarde);

#endif


    