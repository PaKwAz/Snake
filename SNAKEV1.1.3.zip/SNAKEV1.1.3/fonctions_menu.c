#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>
#include "fct_menu.h"
#include "fct_types.h"

void creer_bouton(int x, int y, int width, int height, char* texte, 
                  MLV_Color couleur_fond, MLV_Color couleur_texte, MLV_Font* font) {
    MLV_draw_filled_rectangle(x, y, width, height, couleur_fond);
    
    MLV_draw_rectangle(x, y, width, height, MLV_rgba(101, 67, 33, 255));
    MLV_draw_rectangle(x+2, y+2, width-4, height-4, MLV_rgba(139, 90, 43, 255));
    
    int text_width, text_height;
    MLV_get_size_of_text_with_font(texte, &text_width, &text_height, font);
    
    int text_x = x + (width - text_width) / 2;
    int text_y = y + (height - text_height) / 2;
    
    MLV_draw_text_with_font(text_x, text_y, texte, font, couleur_texte);
}

void animation_clic_bouton(int x, int y, int width, int height, char* texte, MLV_Font* font) {
    
    creer_bouton(x, y, width, height, texte, MLV_rgba(255, 215, 0, 255), 
                 MLV_rgba(139, 69, 19, 255), font);
    
    MLV_actualise_window();
    MLV_wait_milliseconds(75);
}

int clic_bouton(int bx, int by, int bw, int bh, int mx, int my) {
    return (mx >= bx && mx <= bx + bw &&
            my >= by && my <= by + bh);
}

void afficher_menu(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {
  MLV_Font* tscore = MLV_load_font("assets/ARCADE_N.TTF", 40);
  char* titre = "TRAIN TRAIN";
  int titre_w, titre_h;
  int meilleurscore1, meilleurscore2, meilleurscore3;
  if (get_scores(&meilleurscore1, &meilleurscore2, &meilleurscore3)){
    meilleurscore1 = 0; meilleurscore2 = 0; meilleurscore3 = 0;
  }

  MLV_draw_image(fond,0,0);
    
  MLV_get_size_of_text_with_font(titre, &titre_w, &titre_h, font_titre);
    
  MLV_draw_text_with_font((1500 - titre_w) / 2 + 3, 53, titre, font_titre, MLV_COLOR_BLACK);
  MLV_draw_text_with_font((1500 - titre_w) / 2, 50, titre, font_titre, MLV_rgba(125, 255, 0, 1));

  /*----------------------------------SCORES------------------------*/

  creer_bouton(800, 337, 400, 325, "", MLV_rgba(184, 134, 11, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

  MLV_draw_text_with_font(825+3, 365, "Meilleurs", tscore, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(825, 365, "Meilleurs", tscore, MLV_rgba(139, 0, 0, 255));
  MLV_draw_text_with_font(825+3, 415, "scores :", tscore, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(825, 415, "scores :", tscore, MLV_rgba(139, 0, 0, 255));
     
  MLV_draw_adapted_text_box_with_font(825, 475, "#1 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleurscore1);

  MLV_draw_adapted_text_box_with_font(825, 525, "#2 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleurscore2);

  MLV_draw_adapted_text_box_with_font(825, 575, "#3 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleurscore3);

  /*----------------------------------BOUTONS------------------------*/
    
  creer_bouton(250, 250, 500, 100, "NOUVELLE PARTIE", 
	       MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
  creer_bouton(250, 370, 500, 100, "CONTINUER", 
	       MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
  creer_bouton(250, 490, 500, 100, "2 JOUEURS", 
	       MLV_rgba(184, 134, 11, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
  creer_bouton(250, 610, 500, 100, "COMMANDES", 
	       MLV_rgba(218, 165, 32, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
  creer_bouton(250, 730, 500, 100, "QUITTER", 
	       MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
  MLV_actualise_window();
}

void afficher_menu_cote(int *score) {
    MLV_Font* tscore = MLV_load_font("assets/ARCADE_N.TTF", 40);
    MLV_Font* echap = MLV_load_font("assets/ARCADE_N.TTF", 25);
    int tscore_w, tscore_h;
    int echap_w, echap_h;
    int meilleurscore1, meilleurscore2, meilleurscore3;
    if (get_scores(&meilleurscore1, &meilleurscore2, &meilleurscore3)){
        meilleurscore1 = 0; meilleurscore2 = 0; meilleurscore3 = 0;
    }

    
    MLV_get_size_of_text_with_font("SCORE :", &tscore_w, &tscore_h, tscore);
    MLV_get_size_of_text_with_font("echap pour pause", &echap_w, &echap_h, echap);

    creer_bouton(1000, 10, 490, 978, "", MLV_rgba(184, 134, 11, 255), MLV_rgba(255, 248, 220, 255), echap);
    
    MLV_draw_text_with_font((1000 + (500 - tscore_w) / 2 -75)+3, 50, "Score :", tscore, MLV_COLOR_BLACK);
    MLV_draw_text_with_font(1000 + (500 - tscore_w) / 2 -75, 50, "Score :", tscore, MLV_rgba(139, 0, 0, 255));
    
    MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 125, "%d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, *score);

    MLV_draw_text_with_font((1000 + (500 - tscore_w) / 2 -75)+3, 225, "Meilleurs :", tscore, MLV_COLOR_BLACK);
    MLV_draw_text_with_font(1000 + (500 - tscore_w) / 2 -75, 225, "Meilleurs :", tscore, MLV_rgba(139, 0, 0, 255));
     
    MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 300, "#1 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleurscore1);

    MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 350, "#2 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleurscore2);

    MLV_draw_adapted_text_box_with_font(1000 + (500 - tscore_w) / 2 -75, 400, "#3 : %d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, meilleurscore3);


    MLV_draw_text_with_font(1000 + (500 - echap_w) / 2, 950, "echap pour pause", echap, MLV_rgba(255, 215, 0, 255));
    
}

void afficher_continuer(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {
    
    char* titre = "CHARGER";
    int titre_w, titre_h;

    MLV_draw_image(fond,0,0);
    MLV_get_size_of_text_with_font(titre, &titre_w, &titre_h, font_titre);
    
    MLV_draw_text_with_font((1500 - titre_w) / 2 + 3, 53, titre, font_titre, MLV_COLOR_BLACK);
    MLV_draw_text_with_font((1500 - titre_w) / 2, 50, titre, font_titre, MLV_rgba(125, 255, 0, 1));
    
    creer_bouton(500, 250, 500, 100, "Sauvegarde 1", 
                 MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(500, 400, 500, 100, "Sauvegarde 2", 
                 MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(500, 550, 500, 100, "Sauvegarde 3", 
                 MLV_rgba(205, 133, 63, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(1050, 800, 300, 90, "RETOUR", 
                 MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    MLV_actualise_window();
}

void afficher_nouvelle(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {

    char* titre = "NOUVELLE";
    int titre_w, titre_h;

    MLV_draw_image(fond,0,0);
    MLV_get_size_of_text_with_font(titre, &titre_w, &titre_h, font_titre);
    
    MLV_draw_text_with_font((1500 - titre_w) / 2 + 3, 53, titre, font_titre, MLV_COLOR_BLACK);
    MLV_draw_text_with_font((1500 - titre_w) / 2, 50, titre, font_titre, MLV_rgba(125, 255, 0, 1));
    
    creer_bouton(500, 250, 500, 100, "Ecraser 1", 
                 MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(500, 400, 500, 100, "Ecraser 2", 
                 MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(500, 550, 500, 100, "Ecraser 3", 
                 MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    creer_bouton(1050, 800, 300, 90, "RETOUR", 
                 MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
    
    MLV_actualise_window();
}

void afficher_2joueurs() {
    MLV_clear_window(MLV_rgba(139, 90, 43, 255));
    MLV_actualise_window();
}

int boucle_menu(int width, int height) {
    int i = 1, test = 0;
    int mx, my;
    MLV_Image* fond = MLV_load_image("assets/fond.png");
    MLV_Font* font_titre = MLV_load_font("assets/ARCADE_N.TTF", 100);
    MLV_Font* font_bouton = MLV_load_font("assets/ARCADE_N.TTF", 20);
    
    if (!font_titre || !font_bouton) {
        return -1;
    }
    
    while (i == 1) {
      afficher_menu(font_titre, font_bouton, fond);
        
        MLV_wait_mouse(&mx, &my);
        
        if (clic_bouton(250, 370, 500, 100, mx, my)) {
	  animation_clic_bouton(250, 370, 500, 100, "CONTINUER", font_bouton);
	  if (boucle_continuer(width, height, font_titre, font_bouton, fond) == -1) {
                i = 0;
                test = -1;
            }
        }
        
        if (clic_bouton(250, 490, 500, 100, mx, my)) {
            animation_clic_bouton(250, 490, 500, 100, "2 JOUEURS", font_bouton);
            boucle_2joueurs(width, height);
        }
        
        if (clic_bouton(250, 250, 500, 100, mx, my)) {
            animation_clic_bouton(250, 250, 500, 100, "NOUVELLE PARTIE", font_bouton);
            if (boucle_nouvelle(width, height, font_titre, font_bouton, fond) == -1) {
                i = 0;
                test = -1;
            }
        }
        
        if (clic_bouton(250, 730, 500, 100, mx, my)) {
            animation_clic_bouton(250, 730, 500, 100, "QUITTER", font_bouton);
            i = 0;
        }
    }
    
    MLV_free_font(font_titre);
    MLV_free_font(font_bouton);
    
    return test;
}

int boucle_continuer(int width, int height, MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {
    int i = 1, test = 0;
    int mx, my;
    
    while (i == 1) {
      afficher_continuer(font_titre, font_bouton, fond);
        
        MLV_wait_mouse(&mx, &my);
        
        if (clic_bouton(1050, 800, 300, 90, mx, my)) {
            animation_clic_bouton(1050, 800, 300, 90, "RETOUR", font_bouton);
            i = 0;
        }
        
        if (clic_bouton(500, 250, 500, 100, mx, my)) {
            animation_clic_bouton(500, 250, 500, 100, "Sauvegarde 1", font_bouton);
        }
        
        if (clic_bouton(500, 400, 500, 100, mx, my)) {
            animation_clic_bouton(500, 400, 500, 100, "Sauvegarde 2", font_bouton);
        }
        
        if (clic_bouton(500, 550, 500, 100, mx, my)) {
            animation_clic_bouton(500, 550, 500, 100, "Sauvegarde 3", font_bouton);
        }
    }
    
    return test;
}

int boucle_nouvelle(int width, int height, MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond) {
    int i = 1, test = 0;
    int mx, my;
    
    while (i == 1) {
      afficher_nouvelle(font_titre, font_bouton, fond);
        
        MLV_wait_mouse(&mx, &my);
        
        if (clic_bouton(1050, 800, 300, 90, mx, my)) {
            animation_clic_bouton(1050, 800, 300, 90, "RETOUR", font_bouton);
            i = 0;
        }
        
        if (clic_bouton(500, 250, 500, 100, mx, my)) {
            animation_clic_bouton(500, 250, 500, 100, "Ecraser 1", font_bouton);
        }
        
        if (clic_bouton(500, 400, 500, 100, mx, my)) {
            animation_clic_bouton(500, 400, 500, 100, "Ecraser 2", font_bouton);
        }
        
        if (clic_bouton(500, 550, 500, 100, mx, my)) {
            animation_clic_bouton(500, 550, 500, 100, "Ecraser 3", font_bouton);
        }
    }
    
    return test;
}

void boucle_2joueurs(int width, int height) {
    int i = 0;
    while (i == 0) {
        afficher_2joueurs();
        i = main_jeu(1000, 1500);
    }
}
