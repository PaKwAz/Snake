#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

void afficher_perdu(MLV_Font* font_titre, MLV_Font* font_bouton, int*score, int record);
int boucle_perdu(int * score, int record);
