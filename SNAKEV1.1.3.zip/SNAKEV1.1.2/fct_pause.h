#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

void afficher_pause(MLV_Font* font_titre, MLV_Font* font_bouton, int*score);
int boucle_pause(int *score);
