#include "fct_types.h"
#include "fct_menu.h"
#include "fct_pause.h"
#include "fct_perdu.h"
#include "fct_sauvegarde.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

int buffer_direction[3];
int taille_buffer = 0;

void test_toutes_les_images(){
    MLV_Image* img;
    int i;
    char fichiers[9][40] = {
        "assets/random.png", 
        "assets/wagon.png", 
        "assets/wagon_cote.png",
        "assets/locomotive_h.png", 
        "assets/locomotive_d.png", 
        "assets/locomotive_b.png", 
        "assets/locomotive_g.png",
        "assets/charbon.png", 
        "assets/cactus.png"
    };

    for(i = 0; i < 9; i++){
        img = MLV_load_image(fichiers[i]);
        if(!img){
            fprintf(stderr, "Erreur fatale : Image manquante -> %s\n", fichiers[i]);
            exit(EXIT_FAILURE);
        }
        MLV_free_image(img);
    }
}

void tenir_a_j_liste(int coordonnees[361][2], int xtete, int ytete, int longueur){
    int i;
    for ( i = longueur ; i > 0 ; i-- ){
        coordonnees[i][0] = coordonnees[i-1][0];
        coordonnees[i][1] = coordonnees[i-1][1];
    }
    coordonnees[0][0] = xtete;
    coordonnees[0][1] = ytete;
}

void ajouter_liste(int coordonnees[361][2], int x, int y, int longueur){
    coordonnees[longueur-1][0] = x;
    coordonnees[longueur-1][1] = y;
}

MLV_Color get_couleur_case(int x, int y){
    if ( (x+y) % 2 == 0 ) return MLV_COLOR_PERU;
    else return MLV_COLOR_SANDY_BROWN;
}

void afficher_image(MLV_Image* image, int x, int y, int hauteur){
    if (!image){
        exit(EXIT_FAILURE);
    }
    int taille_case = hauteur / taille_max;
    MLV_draw_image(image, x*taille_case, y*taille_case);
}

void spawn_random(cases plateau[taille_max][taille_max], int hauteur){
    int i, j, bonus;
    int taille_case = hauteur/taille_max;
    MLV_Color couleur;
    MLV_Image* image = MLV_load_image("assets/random.png");
    for ( i = 0 ; i < taille_max ; i++ ){
        for ( j = 0 ; j < taille_max ; j++ ){
            if ( plateau[i][j].compteur < -1 ){
                plateau[i][j].compteur = 0;
                couleur = get_couleur_case(i,j);
                MLV_draw_filled_rectangle( i, j, taille_case, taille_case, couleur );
            }
            
        }
    }
    do {
        i = rand()%taille_max+1;
        j = rand()%taille_max+1;
    }
    while (plateau[i][j].compteur != 0);
    bonus = ( rand()%5 ) + 1;
    plateau[i][j].compteur -= bonus;
    afficher_image( image, i, j, hauteur);
    MLV_free_image(image);
}

void effacer_train(int coordonnees[361][2], int longueur, int hauteur, int direction_tete){
    int k;
    int x, y;
    MLV_Color couleur;

    for (k = 0; k < longueur; k++) {
        x = coordonnees[k][0];
        y = coordonnees[k][1];
        
        couleur = get_couleur_case(x, y);
        affichage_jeu(x, y, hauteur, couleur, 1);
    }
    
    x = coordonnees[0][0]; 
    y = coordonnees[0][1];
    
    switch(direction_tete){
        case 1: y--; if(y < 0) y = taille_max - 1; break;
        case 2: x = (x + 1) % taille_max; break;         
        case 3: y = (y + 1) % taille_max; break;         
        case 4: x--; if(x < 0) x = taille_max - 1; break; 
    }

    couleur = get_couleur_case(x, y);
    affichage_jeu(x, y, hauteur, couleur, 1);
}

void affichage_train(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, float pourcentage, int direction_tete){
    effacer_train(coordonnees,longueur,hauteur,direction_tete);

    MLV_Image* image;
    MLV_Image* wagon = MLV_load_image("assets/wagon.png");
    MLV_Image* wagon_c = MLV_load_image("assets/wagon_cote.png");
    MLV_Image* loc_h = MLV_load_image("assets/locomotive_h.png");
    MLV_Image* loc_d = MLV_load_image("assets/locomotive_d.png");
    MLV_Image* loc_b = MLV_load_image("assets/locomotive_b.png");
    MLV_Image* loc_g = MLV_load_image("assets/locomotive_g.png");

    

    int taille_case = hauteur / taille_max;
    int cur_x, cur_y, dest_x, dest_y;
    float pixel_x, pixel_y;
    int diff_x, diff_y;

    for (int i = 0; i < longueur; i++) {
        cur_x = coordonnees[i][0];
        cur_y = coordonnees[i][1];

        if (i == 0) {
            dest_x = cur_x; dest_y = cur_y;
            switch(direction_tete){
                case 1: dest_y--; if(dest_y < 0) dest_y = taille_max - 1; break;
                case 2: dest_x = (dest_x + 1) % taille_max; break;
                case 3: dest_y = (dest_y + 1) % taille_max; break;
                case 4: dest_x--; if(dest_x < 0) dest_x = taille_max - 1; break;
            }
        } else {
            dest_x = coordonnees[i-1][0];
            dest_y = coordonnees[i-1][1];
        }

        diff_x = dest_x - cur_x;
        diff_y = dest_y - cur_y;

        if (abs(diff_x) > 1 || abs(diff_y) > 1) {
             pixel_x = cur_x * taille_case;
             pixel_y = cur_y * taille_case;
        } else {
            pixel_x = (cur_x + (float)diff_x * pourcentage) * taille_case;
            pixel_y = (cur_y + (float)diff_y * pourcentage) * taille_case;
        }

        if (i == 0) {
             switch(direction_tete) {
                case 1: image = loc_h; break;
                case 2: image = loc_d; break;
                case 3: image = loc_b; break;
                case 4: image = loc_g; break;
            }
        } else {
            if (plateau[cur_x][cur_y].direction % 2 == 0) image = wagon_c;
            else image = wagon;
        }

        MLV_draw_image(image, (int)pixel_x, (int)pixel_y);
    }
    MLV_actualise_window();
    MLV_free_image(wagon);
    MLV_free_image(wagon_c);
    MLV_free_image(loc_h);
    MLV_free_image(loc_d);
    MLV_free_image(loc_b);
    MLV_free_image(loc_g);
    

    if(image != NULL) {
        MLV_free_image(image);
    }
}

void affichage_jeu(int x, int y, int hauteur, MLV_Color couleur, int transformer_x_y){
    int taille_case = hauteur / taille_max;
    if (transformer_x_y == 1) {
        MLV_draw_filled_rectangle(x * taille_case, y * taille_case, taille_case, taille_case, couleur);
    } else {
        MLV_draw_filled_rectangle(x, y, taille_case, taille_case, couleur);
    }
}

void spawn_pomme(cases plateau[taille_max][taille_max], int hauteur){
    int xpomme, ypomme;
    MLV_Image* image = MLV_load_image("assets/charbon.png");
    do{
        xpomme = rand() % taille_max;
        ypomme = rand() % taille_max;
    } while (plateau[xpomme][ypomme].compteur != 0);
    
    plateau[xpomme][ypomme].compteur = -1;
    afficher_image(image, xpomme, ypomme, hauteur);
    MLV_free_image(image);
}

void init_plat(cases plateau[taille_max][taille_max], int *xtete, int *ytete, int hauteur, int save){
    int i, j;
    for (i = 0; i < taille_max; i++){
        for (j = 0; j < taille_max; j++){
            plateau[i][j].serpent = 0;
            plateau[i][j].compteur = 0;
            plateau[i][j].direction = 0;
        }
    }
    if ( save == 0 ) {
        *xtete = 9;
        *ytete = 9;
        plateau[9][9].serpent = 1;
        plateau[9][9].compteur = 1;
        plateau[9][9].direction = 1;
    }
}

void affichage_initial(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, int largeur, int pomme){
    int i, j;
    MLV_Image* pomme_image = MLV_load_image("assets/charbon.png");
    MLV_clear_window(MLV_COLOR_BLACK);
    for (i = 0; i < taille_max; i++){
        for (j = 0; j < taille_max; j++){
            if ((i + j) % 2 == 0) affichage_jeu(i, j, hauteur, MLV_COLOR_PERU, 1);
            else affichage_jeu(i, j, hauteur, MLV_COLOR_SANDY_BROWN, 1);
            if ( plateau[i][j].compteur == -1 ) afficher_image(pomme_image,i,j,hauteur);
        }
    }
    
    if ( pomme == 1) spawn_pomme(plateau, hauteur);

    affichage_train(plateau, coordonnees, longueur, hauteur, 0.0, 1);
    MLV_actualise_window();
    MLV_wait_milliseconds(150);
    MLV_free_image(pomme_image);
}

void avancer_tete(cases plateau[taille_max][taille_max], int xtete, int ytete, int longueur, int direction){
    plateau[xtete][ytete].serpent = 1;
    plateau[xtete][ytete].compteur = longueur;
    plateau[xtete][ytete].direction = direction;
}

int get_scores(int meilleur[taille_meilleur]) {
  FILE* records = fopen("records.txt", "r");
    
  if (records == NULL) {
    return 1;
  }
    
  int ret = 0;
  for (int i = 0; i < 10; i++) {
    if (fscanf(records, "%d", &meilleur[i]) != 1) {
      ret = 1;
    }
  }
    
  fclose(records);
  return ret;
}

void ecrire_res(int meilleur[taille_meilleur]) {
  FILE* records = fopen("records.txt", "w");
    
  for (int i = 0; i < 10; i++) {
    fprintf(records, "%d\n", meilleur[i]);
  }
    
  fclose(records);
}

void ajouter_au_buffer(int nouvelle_dir, int direction_actuelle) {
    if (taille_buffer >= 3) return;
    int derniere_dir;
    if (taille_buffer > 0) derniere_dir = buffer_direction[taille_buffer - 1];
    else derniere_dir = direction_actuelle;

    if (derniere_dir == 1 && nouvelle_dir == 3) return;
    if (derniere_dir == 3 && nouvelle_dir == 1) return;
    if (derniere_dir == 2 && nouvelle_dir == 4) return;
    if (derniere_dir == 4 && nouvelle_dir == 2) return;
    if (derniere_dir == nouvelle_dir) return;

    buffer_direction[taille_buffer] = nouvelle_dir;
    taille_buffer++;
}

void actualiser_direction_depuis_buffer(int *direction) {
    if (taille_buffer > 0) {
        *direction = buffer_direction[0];
        for(int i = 0; i < taille_buffer - 1; i++){
            buffer_direction[i] = buffer_direction[i+1];
        }
        taille_buffer--;
    }
}

int attendre_et_ecouter(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, int attente, int direction_actuelle, int nb_pommes, int num_sauvegarde, float *chrono, float *temps_en_moins, float base, int score) {
    int debut_attente = MLV_get_time();
    int temps_ecoule;
    float pourcentage = 0.0, debut_pause;
    int quitter = 0;
    int arret = 1;
    int quit = 1;
    MLV_Event event;
    MLV_Keyboard_button touche;
    MLV_Button_state etat;

    while (arret) {
        temps_ecoule = MLV_get_time() - debut_attente;
        
        pourcentage = (float)temps_ecoule / (float)attente;
        if (pourcentage >= 1.0) {
            pourcentage = 1.0; 
           affichage_train(plateau, coordonnees, longueur, hauteur, pourcentage, direction_actuelle);
            arret = 0;
        }

        else {
            affichage_train(plateau, coordonnees, longueur, hauteur, pourcentage, direction_actuelle);

            event = MLV_get_event(&touche, NULL, NULL, NULL, NULL, NULL, NULL, NULL, &etat);
            if (event == MLV_KEY && etat == MLV_PRESSED) {
                int nouv = 0;
                switch(touche){
                case MLV_KEYBOARD_UP : nouv = 1; break;
                case MLV_KEYBOARD_RIGHT : nouv = 2; break;
                case MLV_KEYBOARD_DOWN : nouv = 3; break;
                case MLV_KEYBOARD_LEFT : nouv = 4; break;
                case MLV_KEYBOARD_ESCAPE : debut_pause = MLV_get_time()*0.001 ;
                    quitter = boucle_pause(plateau, longueur, coordonnees, num_sauvegarde, nb_pommes, *chrono, score);
                    affichage_initial(plateau, coordonnees, longueur, hauteur, hauteur, 0);
                    if (quitter == 1){
		      quit = 0;
		    } else {
		      debut_attente = MLV_get_time() - temps_ecoule;
		      *temps_en_moins += MLV_get_time()*0.001 - debut_pause;
		    }
                    break;
                default: break;
                }
                if (nouv != 0) ajouter_au_buffer(nouv, direction_actuelle);
            }
	    if (quitter != 1){
	      MLV_wait_milliseconds(10);
	      *chrono = (MLV_get_time()*0.001) - *temps_en_moins + base;
	      
	    }
        }
    }
    
    return quit;
}


void calculer_position_future(int xtete, int ytete, int direction, int *futur_x, int *futur_y){
    *futur_x = xtete;
    *futur_y = ytete;
    switch(direction){
        case 1: (*futur_y)--; if(*futur_y < 0) *futur_y = taille_max - 1; break;
        case 2: (*futur_x) = (*futur_x + 1) % taille_max; break;
        case 3: (*futur_y) = (*futur_y + 1) % taille_max; break;
        case 4: (*futur_x)--; if(*futur_x < 0) *futur_x = taille_max - 1; break;
    }
}

void spawn_mur(cases plateau[taille_max][taille_max], int hauteur){
    int i, j;
    MLV_Image* image = MLV_load_image("assets/cactus.png");
    do {
        i = rand()%taille_max+1;
        j = rand()%taille_max+1;
    }
    while (plateau[i][j].compteur != 0);
    plateau[i][j].compteur -= 10 ;
    afficher_image(image, i, j, hauteur);
    MLV_free_image(image);        
}

void verifier_interaction_case(cases plateau[taille_max][taille_max], int futur_x, int futur_y, int hauteur, int *pafini, int *a_mange, int *nbpomme, int *longueur, int *coef){
    
    switch (plateau[futur_x][futur_y].compteur){
    case 0 : break;
    case -1 :
        *a_mange = 1;
        *nbpomme += 1;        
        spawn_pomme(plateau, hauteur);
        break;
    case -2 : *nbpomme *= 2; break;
    case -3 : *longueur = *longueur/2; break;
    case -4 : spawn_mur(plateau, hauteur); break;
    case -5 : *coef += 0.2 ; break;
    case -10 : *pafini = 0; break;
    default : *pafini = 0; break;
    }
}


void deplacer_serpent(cases plateau[taille_max][taille_max], int coordonnees[361][2], int xtete, int ytete, int futur_x, int futur_y, int *longueur, int a_mange, int direction, int hauteur){
    int queue_x, queue_y;
    MLV_Color couleur_fond;


    if (a_mange == 0) {
        queue_x = coordonnees[*longueur-1][0];
        queue_y = coordonnees[*longueur-1][1];
        
        plateau[queue_x][queue_y].serpent = 0;
        plateau[queue_x][queue_y].compteur = 0;
        plateau[queue_x][queue_y].direction = 0;
        
        couleur_fond = get_couleur_case(queue_x, queue_y);
        affichage_jeu(queue_x, queue_y, hauteur, couleur_fond, 1);
    } else {
        (*longueur)++;
    }


    plateau[xtete][ytete].serpent = 0;

 
    tenir_a_j_liste(coordonnees, futur_x, futur_y, *longueur);
    avancer_tete(plateau, futur_x, futur_y, *longueur, direction);
}


void mettre_a_jour_scores(int score, int meilleur[taille_meilleur], int nouvelle_liste[taille_meilleur]) {
    int i = 0;
    int j = 0;
    int insere = 0;

    while (j < taille_meilleur) {
        if (insere == 0 && score > meilleur[i]) {
            nouvelle_liste[j] = score;
            insere = 1;
        } else {
            nouvelle_liste[j] = meilleur[i];
            i = i + 1;
        }
        j = j + 1;
    }
    
}



int main_jeu(int hauteur, int largeur, int save){
    int lecture_save;
    int i;
    int pafini = 1, quitter = 0, quit_jeu = 0, rejouer = 0;
    int direction = 1, attente = 130;
    int xtete, ytete, futur_x, futur_y;
    int longueur = 1, score = 0, nb_pommes = 0, a_mange = 0, pomme = 1;
    float chrono, temps_en_moins, base = 0.0;
    cases plateau[taille_max][taille_max];
    int coordonnees[361][2], nv_liste_scores[taille_meilleur];
    int meilleur[10];
    int temps_depuis_pomme = 0;
    int coef = 0.8;

    srand(time(NULL));
    test_toutes_les_images();

    init_plat(plateau, &xtete, &ytete, hauteur, save);

    if ( save != 0 ){
        lecture_save = lire_sauvegarde( plateau, &longueur, coordonnees, save, &nb_pommes, &base, &temps_depuis_pomme);
        printf("%f", chrono);
        pomme = 0;
        score = nb_pommes * 100 - coef * temps_depuis_pomme;
        if ( lecture_save == 0 ) exit(EXIT_FAILURE);
        xtete = coordonnees[0][0], ytete = coordonnees[0][1];
        direction = plateau[xtete][ytete].direction;
        
    }
    else ajouter_liste(coordonnees, xtete, ytete, longueur);
    taille_buffer = 0;
    
    
    affichage_initial(plateau, coordonnees, longueur, hauteur, largeur, pomme);
    
 
    if (get_scores(meilleur)){
      for (i=0; i<10; i++) meilleur[i] = 0;
    }
    afficher_menu_cote(score, meilleur);
    temps_en_moins = MLV_get_time()*0.001;
   
    do {
        actualiser_direction_depuis_buffer(&direction);
        quitter = attendre_et_ecouter(plateau, coordonnees, longueur, hauteur, attente, direction, nb_pommes, save, &chrono, &temps_en_moins, base, MLV_get_time()*0.001 - temps_depuis_pomme);
        if (quitter == 0){
	  quit_jeu = 1;
	} else {
        
	  calculer_position_future(xtete, ytete, direction, &futur_x, &futur_y);
	  a_mange = 0; 

        
	  verifier_interaction_case(plateau, futur_x, futur_y, hauteur, &pafini, &a_mange, &nb_pommes, &longueur, &coef);
	  

        
	  if (pafini) {
            deplacer_serpent(plateau, coordonnees, xtete, ytete, futur_x, futur_y, &longueur, a_mange, direction, hauteur);
            xtete = futur_x;
            ytete = futur_y;
            if (chrono / 20 < 1) spawn_random(plateau, hauteur);
	  }
          if ( a_mange ) temps_depuis_pomme = MLV_get_time()*0.001;
          score = nb_pommes * 100 - coef * MLV_get_time()*0.001 - temps_depuis_pomme;
          if ( score < 0 ) score = 0;
	  
	  mettre_a_jour_scores(score, meilleur, nv_liste_scores);
          afficher_menu_cote(score, nv_liste_scores);
          afficher_chrono(chrono);
	}
        
	
    } while (pafini && quitter);

    if (quit_jeu != 1){
        rejouer = boucle_perdu(&score);
        ecrire_res(nv_liste_scores);
        if (rejouer == 0) quit_jeu = 0;
        else quit_jeu = 1; 
    }
    
    
    return quit_jeu;
}
