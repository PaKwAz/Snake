#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>
#include "fct_menu.h"
#include "fct_pause.h"
#include "fct_perdu.h"

void afficher_perdu(MLV_Font* font_titre, MLV_Font* font_bouton, int*score){

  MLV_Font* tscore = MLV_load_font("assets/ARCADE_N.TTF", 40);
  char* titre = "PERDU !";
  int titre_w, titre_h;
  
  MLV_get_size_of_text_with_font(titre, &titre_w, &titre_h, font_titre);
  
  creer_bouton(250, 250, 500, 500, "", MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

  MLV_draw_text_with_font(250 + (500 - titre_w) / 2 + 3, 275, titre, font_titre, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(250 + (500 - titre_w) / 2, 275, titre, font_titre, MLV_rgba(125, 255, 0, 1));

  MLV_draw_text_with_font(275+3, 400, "Score :", tscore, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(275, 400, "Score :", tscore, MLV_rgba(184, 134, 11, 255));
  
  MLV_draw_adapted_text_box_with_font(275 , 475, "%d", tscore, 0, MLV_rgba(0,0,0,0), MLV_rgba(255, 215, 0, 255), MLV_rgba(0,0,0,0), MLV_TEXT_LEFT, *score);

  creer_bouton(375, 600, 250, 50, "Rejouer", MLV_rgba(218, 165, 32, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  
  creer_bouton(375, 675, 250, 50, "Quitter", MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

  MLV_actualise_window();
}

int boucle_perdu(int * score){
  MLV_Font* font_titre = MLV_load_font("assets/ARCADE_N.TTF", 50);
  MLV_Font* font_bouton = MLV_load_font("assets/ARCADE_N.TTF", 20);
  int mx;
  int my;
  int i=1;
  int quit = 0;
  afficher_perdu(font_titre, font_bouton, score);
  while (i==1){
    MLV_wait_mouse(&mx,&my);
    if (clic_bouton(375,600,250,50,mx,my)){
      animation_clic_bouton(375, 600, 250, 50, "Rejouer", font_bouton);
      i--;
      quit = 0;
    }
    if (clic_bouton(375,675,250,50,mx,my)){
      animation_clic_bouton(375, 675, 250, 50, "Quitter", font_bouton);
      i--;
      quit = 1;
    }
  }
  return quit;
}
