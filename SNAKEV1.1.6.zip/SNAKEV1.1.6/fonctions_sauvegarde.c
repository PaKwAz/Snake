#include "fct_sauvegarde.h"
#include "fct_types.h"
#include <stdio.h>
#include <stdlib.h>

void get_pomme(cases plateau[taille_max][taille_max], int * xpomme, int *ypomme){
    int i, j;
    for ( i = 0 ; i < taille_max ; i++ ){
        for ( j = 0 ; j < taille_max ; j++ ){
            if ( plateau[i][j].compteur == -1 ) *xpomme = i, *ypomme = j, i = taille_max, j = taille_max;
        }
    }
}

int lire_sauvegarde(cases plateau[taille_max][taille_max], int *longueur, int coordonnees [361][2], int num_sauvegarde, int *score, float *chrono){
    FILE* save;
    int i, x, y, len, ret;

    if ( num_sauvegarde == 1 ) save = fopen( "save1.txt", "r" );
    else if ( num_sauvegarde == 2 ) save = fopen( "save2.txt", "r" );
    else if ( num_sauvegarde == 2 ) save = fopen( "save3.txt", "r" );
    else if ( num_sauvegarde == 2 ) save = fopen( "save4.txt", "r" );
    else printf ("Erreur, sauvegarde impossible"), exit(EXIT_FAILURE);

    if (save == NULL) ret = 0;

    else {
        fscanf(save, "%d", &len);
        *longueur = len;

        for ( i = 0 ; i < len ; i ++ ){
            fscanf(save, "%d %d", &x, &y);
            coordonnees[i][0] = x, coordonnees[i][1] = y;
            fscanf(save, "%d %d %d", &plateau[x][y].serpent, &plateau[x][y].compteur, &plateau[x][y].direction);
            
        }
        fscanf(save, "%d %d", &x, &y);
        plateau[x][y].compteur = -1;
        plateau[x][y].serpent = 0;
        plateau[x][y].direction = 1;
        ret = 1;

        fscanf(save, "%d", score);
        fscanf(save, "%f", chrono);
        fclose(save);
        
    }
    
    return ret;
}

void sauvegarder(cases plateau[taille_max][taille_max], int longueur, int coordonnees [361][2], int num_sauvegarde, int score, float chrono){
    FILE* save;
    int xpomme, ypomme, i, x, y;
    if ( num_sauvegarde == 1 ) save = fopen( "save1.txt", "w" );
    else if ( num_sauvegarde == 2 ) save = fopen( "save2.txt", "w" );
    else if ( num_sauvegarde == 3 ) save = fopen( "save3.txt", "w" );
    else printf ("Erreur, sauvegarde impossible"), exit(EXIT_FAILURE);
    get_pomme(plateau, &xpomme, &ypomme);
    
    fprintf(save,"%d\n", longueur);

    for ( i = 0 ; i < longueur ; i ++){
        x = coordonnees[i][0], y = coordonnees[i][1];
        fprintf(save, "%d %d %d %d %d\n", x, y, plateau[x][y].serpent, plateau[x][y].compteur, plateau[x][y].direction);
    }

    fprintf(save,"%d %d\n", xpomme, ypomme);
    fprintf(save,"%d\n", score);
    fprintf(save,"%f\n", chrono);
    fclose(save);
}
