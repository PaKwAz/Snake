#include "fct_types.h"
#include "fct_menu.h"
#include "fct_pause.h"
#include "fct_perdu.h"
#include "fct_sauvegarde.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

int buffer_direction[3];
int taille_buffer = 0;

void tenir_a_j_liste(int coordonnees[361][2], int xtete, int ytete, int longueur){
    int i;
    for ( i = longueur ; i > 0 ; i-- ){
        coordonnees[i][0] = coordonnees[i-1][0];
        coordonnees[i][1] = coordonnees[i-1][1];
    }
    coordonnees[0][0] = xtete;
    coordonnees[0][1] = ytete;
}

void ajouter_liste(int coordonnees[361][2], int x, int y, int longueur){
    coordonnees[longueur-1][0] = x;
    coordonnees[longueur-1][1] = y;
}

MLV_Color get_couleur_case(int x, int y){
    if ( (x+y) % 2 == 0 ) return MLV_COLOR_PERU;
    else return MLV_COLOR_SANDY_BROWN;
}

void afficher_image(MLV_Image* image, int x, int y, int hauteur){
    if (!image){
        exit(EXIT_FAILURE);
    }
    int taille_case = hauteur / taille_max;
    MLV_draw_image(image, x*taille_case, y*taille_case);
}

void effacer_train(int coordonnees[361][2], int longueur, int hauteur, int direction_tete){
    int k;
    int x, y;
    MLV_Color couleur;

    for (k = 0; k < longueur; k++) {
        x = coordonnees[k][0];
        y = coordonnees[k][1];
        
        couleur = get_couleur_case(x, y);
        affichage_jeu(x, y, hauteur, couleur, 1);
    }
    
    x = coordonnees[0][0]; 
    y = coordonnees[0][1];
    
    switch(direction_tete){
        case 1: y--; if(y < 0) y = taille_max - 1; break;
        case 2: x = (x + 1) % taille_max; break;         
        case 3: y = (y + 1) % taille_max; break;         
        case 4: x--; if(x < 0) x = taille_max - 1; break; 
    }

    couleur = get_couleur_case(x, y);
    affichage_jeu(x, y, hauteur, couleur, 1);
}

void affichage_train(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, float pourcentage, int direction_tete){
    effacer_train(coordonnees,longueur,hauteur,direction_tete);

    MLV_Image* image;
    MLV_Image* wagon = MLV_load_image("assets/wagon.png");
    MLV_Image* wagon_c = MLV_load_image("assets/wagon_cote.png");
    MLV_Image* loc_h = MLV_load_image("assets/locomotive_h.png");
    MLV_Image* loc_d = MLV_load_image("assets/locomotive_d.png");
    MLV_Image* loc_b = MLV_load_image("assets/locomotive_b.png");
    MLV_Image* loc_g = MLV_load_image("assets/locomotive_g.png");

    if (!wagon || !wagon_c || !loc_h || !loc_d || !loc_b || !loc_g) exit(EXIT_FAILURE);

    int taille_case = hauteur / taille_max;
    int cur_x, cur_y, dest_x, dest_y;
    float pixel_x, pixel_y;
    int diff_x, diff_y;

    for (int i = 0; i < longueur; i++) {
        cur_x = coordonnees[i][0];
        cur_y = coordonnees[i][1];

        if (i == 0) {
            dest_x = cur_x; dest_y = cur_y;
            switch(direction_tete){
                case 1: dest_y--; if(dest_y < 0) dest_y = taille_max - 1; break;
                case 2: dest_x = (dest_x + 1) % taille_max; break;
                case 3: dest_y = (dest_y + 1) % taille_max; break;
                case 4: dest_x--; if(dest_x < 0) dest_x = taille_max - 1; break;
            }
        } else {
            dest_x = coordonnees[i-1][0];
            dest_y = coordonnees[i-1][1];
        }

        diff_x = dest_x - cur_x;
        diff_y = dest_y - cur_y;

        if (abs(diff_x) > 1 || abs(diff_y) > 1) {
             pixel_x = cur_x * taille_case;
             pixel_y = cur_y * taille_case;
        } else {
            pixel_x = (cur_x + (float)diff_x * pourcentage) * taille_case;
            pixel_y = (cur_y + (float)diff_y * pourcentage) * taille_case;
        }

        if (i == 0) {
             switch(direction_tete) {
                case 1: image = loc_h; break;
                case 2: image = loc_d; break;
                case 3: image = loc_b; break;
                case 4: image = loc_g; break;
            }
        } else {
            if (plateau[cur_x][cur_y].direction % 2 == 0) image = wagon_c;
            else image = wagon;
        }

        MLV_draw_image(image, (int)pixel_x, (int)pixel_y);
    }
    MLV_actualise_window();
}

void affichage_jeu(int x, int y, int hauteur, MLV_Color couleur, int transformer_x_y){
    int taille_case = hauteur / taille_max;
    if (transformer_x_y == 1) {
        MLV_draw_filled_rectangle(x * taille_case, y * taille_case, taille_case, taille_case, couleur);
    } else {
        MLV_draw_filled_rectangle(x, y, taille_case, taille_case, couleur);
    }
}

void spawn_pomme(cases plateau[taille_max][taille_max], int hauteur){
    int xpomme, ypomme;
    MLV_Image* image = MLV_load_image("assets/charbon.png");
    do{
        xpomme = rand() % taille_max;
        ypomme = rand() % taille_max;
    } while (plateau[xpomme][ypomme].compteur != 0);
    
    plateau[xpomme][ypomme].compteur = -1;
    afficher_image(image, xpomme, ypomme, hauteur);
}

void init_plat(cases plateau[taille_max][taille_max], int *xtete, int *ytete, int hauteur, int save){
    int i, j;
    for (i = 0; i < taille_max; i++){
        for (j = 0; j < taille_max; j++){
            plateau[i][j].serpent = 0;
            plateau[i][j].compteur = 0;
            plateau[i][j].direction = 0;
        }
    }
    if ( save == 0 ) {
        *xtete = 9;
        *ytete = 9;
        plateau[9][9].serpent = 1;
        plateau[9][9].compteur = 1;
        plateau[9][9].direction = 1;
    }
}

void affichage_initial(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, int largeur, int*score, int pomme){
    int i, j;
    MLV_Image* pomme_image = MLV_load_image("assets/charbon.png");
    MLV_clear_window(MLV_COLOR_BLACK);
    for (i = 0; i < taille_max; i++){
        for (j = 0; j < taille_max; j++){
            if ((i + j) % 2 == 0) affichage_jeu(i, j, hauteur, MLV_COLOR_PERU, 1);
            else affichage_jeu(i, j, hauteur, MLV_COLOR_SANDY_BROWN, 1);
            if ( plateau[i][j].compteur == -1 ) afficher_image(pomme_image,i,j,hauteur);
        }
    }
    afficher_menu_cote(score);
    if ( pomme == 1) spawn_pomme(plateau, hauteur);

    affichage_train(plateau, coordonnees, longueur, hauteur, 0.0, 1);
    MLV_actualise_window();
    MLV_wait_milliseconds(150);
}

void avancer_tete(cases plateau[taille_max][taille_max], int xtete, int ytete, int longueur, int direction){
    plateau[xtete][ytete].serpent = 1;
    plateau[xtete][ytete].compteur = longueur;
    plateau[xtete][ytete].direction = direction;
}

int get_scores(int meilleur[taille_meilleur]) {
  FILE* records = fopen("records.txt", "r");
    
  if (records == NULL) {
    return 1;
  }
    
  int ret = 0;
  for (int i = 0; i < 10; i++) {
    if (fscanf(records, "%d", &meilleur[i]) != 1) {
      ret = 1;
    }
  }
    
  fclose(records);
  return ret;
}

void ecrire_res(int meilleur[taille_meilleur]) {
  FILE* records = fopen("records.txt", "w");
    
  for (int i = 0; i < 10; i++) {
    fprintf(records, "%d\n", meilleur[i]);
  }
    
  fclose(records);
}

void ajouter_au_buffer(int nouvelle_dir, int direction_actuelle) {
    if (taille_buffer >= 3) return;
    int derniere_dir;
    if (taille_buffer > 0) derniere_dir = buffer_direction[taille_buffer - 1];
    else derniere_dir = direction_actuelle;

    if (derniere_dir == 1 && nouvelle_dir == 3) return;
    if (derniere_dir == 3 && nouvelle_dir == 1) return;
    if (derniere_dir == 2 && nouvelle_dir == 4) return;
    if (derniere_dir == 4 && nouvelle_dir == 2) return;
    if (derniere_dir == nouvelle_dir) return;

    buffer_direction[taille_buffer] = nouvelle_dir;
    taille_buffer++;
}

void actualiser_direction_depuis_buffer(int *direction) {
    if (taille_buffer > 0) {
        *direction = buffer_direction[0];
        for(int i = 0; i < taille_buffer - 1; i++){
            buffer_direction[i] = buffer_direction[i+1];
        }
        taille_buffer--;
    }
}

int attendre_et_ecouter(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, int attente, int direction_actuelle, int *nb_pommes, int num_sauvegarde, float *chrono, float *temps_en_moins, float base) {
    int debut_attente = MLV_get_time();
    int temps_ecoule;
    float pourcentage = 0.0, debut_pause;
    int quitter = 0;
    int arret = 1;
    int quit = 1;
    int score;
    MLV_Event event;
    MLV_Keyboard_button touche;
    MLV_Button_state etat;

    while (arret) {
        temps_ecoule = MLV_get_time() - debut_attente;
        
        pourcentage = (float)temps_ecoule / (float)attente;
        if (pourcentage >= 1.0) {
            pourcentage = 1.0; 
           affichage_train(plateau, coordonnees, longueur, hauteur, pourcentage, direction_actuelle);
            arret = 0;
        }

        else {
            affichage_train(plateau, coordonnees, longueur, hauteur, pourcentage, direction_actuelle);

            event = MLV_get_event(&touche, NULL, NULL, NULL, NULL, NULL, NULL, NULL, &etat);
            if (event == MLV_KEY && etat == MLV_PRESSED) {
                int nouv = 0;
                switch(touche){
                case MLV_KEYBOARD_UP : nouv = 1; break;
                case MLV_KEYBOARD_RIGHT : nouv = 2; break;
                case MLV_KEYBOARD_DOWN : nouv = 3; break;
                case MLV_KEYBOARD_LEFT : nouv = 4; break;
                case MLV_KEYBOARD_ESCAPE : debut_pause = MLV_get_time()*0.001 ;
                    quitter = boucle_pause(plateau, longueur, coordonnees, num_sauvegarde, nb_pommes, chrono);
		    score = *nb_pommes * 100 - *chrono/2 ;
                    affichage_initial(plateau, coordonnees, longueur, hauteur, hauteur, &score, 0);
                    if (quitter == 1){
		      quit = 0;
		    } else {
		      debut_attente = MLV_get_time() - temps_ecoule;
		      *temps_en_moins += MLV_get_time()*0.001 - debut_pause;
		    }
                    break;
                default: break;
                }
                if (nouv != 0) ajouter_au_buffer(nouv, direction_actuelle);
            }
	    if (quitter != 1){
	      MLV_wait_milliseconds(10);
	      *chrono = (MLV_get_time()*0.001) - *temps_en_moins + base;
	      afficher_chrono(*chrono);
	    }
        }
    }
    
    return quit;
}


void calculer_position_future(int xtete, int ytete, int direction, int *futur_x, int *futur_y){
    *futur_x = xtete;
    *futur_y = ytete;
    switch(direction){
        case 1: (*futur_y)--; if(*futur_y < 0) *futur_y = taille_max - 1; break;
        case 2: (*futur_x) = (*futur_x + 1) % taille_max; break;
        case 3: (*futur_y) = (*futur_y + 1) % taille_max; break;
        case 4: (*futur_x)--; if(*futur_x < 0) *futur_x = taille_max - 1; break;
    }
}


void verifier_interaction_case(cases plateau[taille_max][taille_max], int futur_x, int futur_y, int hauteur, int *pafini, int *a_mange, int *score){
    if (plateau[futur_x][futur_y].compteur > 0) {
        *pafini = 0; 
    }
    else if (plateau[futur_x][futur_y].compteur == -1){
        *a_mange = 1;
        (*score) ++;
        spawn_pomme(plateau, hauteur);
        afficher_menu_cote(score); 
    }
}


void deplacer_serpent(cases plateau[taille_max][taille_max], int coordonnees[361][2], int xtete, int ytete, int futur_x, int futur_y, int *longueur, int a_mange, int direction, int hauteur){
    int queue_x, queue_y;
    MLV_Color couleur_fond;


    if (a_mange == 0) {
        queue_x = coordonnees[*longueur-1][0];
        queue_y = coordonnees[*longueur-1][1];
        
        plateau[queue_x][queue_y].serpent = 0;
        plateau[queue_x][queue_y].compteur = 0;
        plateau[queue_x][queue_y].direction = 0;
        
        couleur_fond = get_couleur_case(queue_x, queue_y);
        affichage_jeu(queue_x, queue_y, hauteur, couleur_fond, 1);
    } else {
        (*longueur)++;
    }


    plateau[xtete][ytete].serpent = 0;

 
    tenir_a_j_liste(coordonnees, futur_x, futur_y, *longueur);
    avancer_tete(plateau, futur_x, futur_y, *longueur, direction);
}


void mettre_a_jour_scores(int score, int meilleur[taille_meilleur]){
  
  if (score > meilleur[9]) {
    int pos = -1;
    for (int i = 0; i < 10 && pos == -1; i++) {
      if (score >= meilleur[i]) {
        pos = i;
      }
    }
    
    if (pos != -1) {
      for (int i = 9; i > pos; i--) {
        meilleur[i] = meilleur[i-1];
      }
      meilleur[pos] = score;
    }
  }
    
  ecrire_res(meilleur);
}


int main_jeu(int hauteur, int largeur, int save){
    int lecture_save;
    int i;
    int pafini = 1, quitter = 0, quit_jeu = 0, rejouer = 0;
    int direction = 1, attente = 130;
    int xtete, ytete, futur_x, futur_y;
    int longueur = 1, score = 0, nb_pommes = 0, a_mange = 0, pomme = 1;
    float chrono, temps_en_moins, base = 0.0;
    cases plateau[taille_max][taille_max];
    int coordonnees[361][2];
    int meilleur[10];

    srand(time(NULL));


    init_plat(plateau, &xtete, &ytete, hauteur, save);

    if ( save != 0 ){
        lecture_save = lire_sauvegarde( plateau, &longueur, coordonnees, save, &score, &base);
        printf("%f", chrono);
        pomme = 0;
        if ( lecture_save == 0 ) exit(EXIT_FAILURE);
        xtete = coordonnees[0][0], ytete = coordonnees[0][1];
        direction = plateau[xtete][ytete].direction;
        
    }
    else ajouter_liste(coordonnees, xtete, ytete, longueur);
    taille_buffer = 0;
    
    
    affichage_initial(plateau, coordonnees, longueur, hauteur, largeur, &score, pomme);
    
 
    if (get_scores(meilleur)){
      for (i=0; i<10; i++) meilleur[i] = 0;
    }
    temps_en_moins = MLV_get_time()*0.001;
   
    do {
        actualiser_direction_depuis_buffer(&direction);
        quitter = attendre_et_ecouter(plateau, coordonnees, longueur, hauteur, attente, direction, &nb_pommes, save, &chrono, &temps_en_moins, base);
        if (quitter == 0){
	  quit_jeu = 1;
	} else {
        
	  calculer_position_future(xtete, ytete, direction, &futur_x, &futur_y);
	  a_mange = 0; 

        
	  verifier_interaction_case(plateau, futur_x, futur_y, hauteur, &pafini, &a_mange, &nb_pommes);
	  score = nb_pommes * 100 - chrono/2 ;

        
	  if (pafini) {
            deplacer_serpent(plateau, coordonnees, xtete, ytete, futur_x, futur_y, &longueur, a_mange, direction, hauteur);
            xtete = futur_x;
            ytete = futur_y;
	  }

	  mettre_a_jour_scores(score, meilleur);
	  if ( a_mange == 1 ) afficher_menu_cote(&score);
	}
	
    } while (pafini && quitter);

    if (quit_jeu != 1){
        rejouer = boucle_perdu(&score);
        if (rejouer == 0) quit_jeu = 0;
        else quit_jeu = 1; 
    }
    
    return quit_jeu;
}
