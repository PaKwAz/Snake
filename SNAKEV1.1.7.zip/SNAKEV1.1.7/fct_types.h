#ifndef _FCT_TYPES_H_
#define _FCT_TYPES_H_

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

#define taille_meilleur 10
#define taille_max 19

typedef struct{
    int serpent;
    int compteur;
    int direction;
} cases;

void tenir_a_j_liste(int coordonnees[361][2], int xtete, int ytete, int longueur);

void ajouter_liste(int coordonnees[361][2], int x, int y, int longueur);

void afficher_image(MLV_Image* image, int x, int y, int hauteur);

void effacer_train(int coordonnees[361][2], int longueur, int hauteur, int direction_tete);

void affichage_train(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, float pourcentage, int direction_tete);

void affichage_jeu(int x, int y, int hauteur, MLV_Color couleur, int transformer_x_y);

void spawn_pomme(cases plateau[taille_max][taille_max], int hauteur);

void init_plat(cases plateau[taille_max][taille_max], int *xtete, int *ytete, int hauteur, int save);

void affichage_initial(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, int largeur, int*score, int pomme);

void avancer_tete(cases plateau[taille_max][taille_max], int xtete, int ytete, int longueur, int direction);

int get_scores( int meilleur[taille_meilleur]);

void ecrire_res( int meilleur[taille_meilleur]);

void ajouter_au_buffer(int nouvelle_dir, int direction_actuelle);

void actualiser_direction_depuis_buffer(int *direction);

int attendre_et_ecouter(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, int attente, int direction_actuelle, int *nb_pommes, int num_sauvegarde, float *chrono, float *temps_en_moins, float base);

void calculer_position_future(int xtete, int ytete, int direction, int *futur_x, int *futur_y);

void verifier_interaction_case(cases plateau[taille_max][taille_max], int futur_x, int futur_y, int hauteur, int *pafini, int *a_mange, int *score);

void deplacer_serpent(cases plateau[taille_max][taille_max], int coordonnees[361][2], int xtete, int ytete, int futur_x, int futur_y, int *longueur, int a_mange, int direction, int hauteur);

void mettre_a_jour_scores(int score, int meilleur[taille_meilleur]);

int main_jeu(int hauteur, int largeur, int save);

#endif
