#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>
#include "fct_types.h"

void afficher_pause(MLV_Font* font_titre, MLV_Font* font_bouton);

void afficher_sauvegarde(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

int boucle_choisir_save(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

int boucle_pause(cases plateau[taille_max][taille_max], int longueur, int coordonnees [361][2], int num_sauvegarde, int * nb_pomme, float *chrono);
