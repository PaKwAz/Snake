#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>
#include "fct_menu.h"
#include "fct_pause.h"
#include "fct_sauvegarde.h"

/* fonctions qui affiche le menu pause une fois appelée*/
void afficher_pause(MLV_Font* font_titre, MLV_Font* font_bouton){
  
  char* titre = "PAUSE :";
  int titre_w, titre_h;
  
  MLV_get_size_of_text_with_font(titre, &titre_w, &titre_h, font_titre);
  
  creer_bouton(250, 250, 500, 500, "", MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

  /* effet de profondeur sur texte*/
  MLV_draw_text_with_font(250 + (500 - titre_w) / 2 + 3, 275, titre, font_titre, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(250 + (500 - titre_w) / 2, 275, titre, font_titre, MLV_rgba(255, 248, 220, 255));
  
  creer_bouton(375, 525, 250, 50, "Sauvegarder", MLV_rgba(184, 134, 11, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  creer_bouton(375, 600, 250, 50, "Reprendre", MLV_rgba(218, 165, 32, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  creer_bouton(375, 675, 250, 50, "Quitter", MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

  MLV_actualise_window();
}

/* fonctions qui affiche le menu des sauvegardes pause une fois appelée*/
void afficher_sauvegarde(MLV_Font* font_titre, MLV_Font* font_bouton) {

  char* titre = "Choix :";
  int titre_w, titre_h;
  
  MLV_get_size_of_text_with_font(titre, &titre_w, &titre_h, font_titre);
  
  creer_bouton(250, 250, 500, 500, "", MLV_rgba(160, 82, 45, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

  MLV_draw_text_with_font(250 + (500 - titre_w) / 2 + 3, 275, titre, font_titre, MLV_COLOR_BLACK);
  MLV_draw_text_with_font(250 + (500 - titre_w) / 2, 275, titre, font_titre, MLV_rgba(255, 248, 220, 255));
  creer_bouton(375, 375, 250, 50, "Sauvegarde 1", MLV_rgba(218, 165, 32, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  creer_bouton(375, 450, 250, 50, "Sauvegarde 2", MLV_rgba(218, 165, 32, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  creer_bouton(375, 525, 250, 50, "Sauvegarde 3", MLV_rgba(218, 165, 32, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  creer_bouton(375, 600, 250, 50, "Sauvegarde 4", MLV_rgba(218, 165, 32, 255), MLV_rgba(255, 248, 220, 255), font_bouton);
  creer_bouton(375, 675, 250, 50, "Retour", MLV_rgba(139, 0, 0, 255), MLV_rgba(255, 248, 220, 255), font_bouton);

  MLV_actualise_window();
}

/*cette boucle gère le cas où le joueur veut sauvegarder son jeu elle renvoie le num de sauvegarde choisie*/
int boucle_choisir_save(MLV_Font* font_titre, MLV_Font* font_bouton){
  int i = 1, save = 0;
  int mx, my;
    
  while (i == 1) {
    afficher_sauvegarde(font_titre, font_bouton);
        
    MLV_wait_mouse(&mx, &my);
        
    if (clic_bouton(375, 675, 250, 50, mx, my)) {
      animation_clic_bouton(375, 675, 250, 50, "RETOUR", font_bouton);
      i = 0;
    }

    /* choix sauvegarde 1*/
    if (clic_bouton(375, 375, 250, 50, mx, my)) {
      animation_clic_bouton(375, 375, 250, 50, "Sauvegarde 1", font_bouton);
      save = 1;
      i = 0;
    }
    /* choix sauvegarde 4*/
    if (clic_bouton(375, 450, 250, 50, mx, my)) {
      animation_clic_bouton(375, 450, 250, 50, "Sauvegarde 2", font_bouton);
      save = 2;
      i = 0;
    }
    /* choix sauvegarde 3*/
    if (clic_bouton(375, 525, 250, 50, mx, my)) {
      animation_clic_bouton(375, 525, 250, 50, "Sauvegarde 3", font_bouton);
      save = 3;
      i = 0;
    }
    /* choix sauvegarde 4*/
    if (clic_bouton(375, 600, 250, 50, mx, my)) {
      animation_clic_bouton(375, 600, 250, 50, "Sauvegarde 4", font_bouton);
      save = 4;
      i = 0;
    }
  }
  return save;
}

/*affiche et gère le menu pause et ses boutons*/
int boucle_pause(cases plateau[taille_max][taille_max], int longueur, int coordonnees [361][2], int num_sauvegarde, int  nb_pomme, float chrono, int score, float coef, int bonus){
  MLV_Font* font_titre = MLV_load_font("ressources/ARCADE_N.TTF", 50);
  MLV_Font* font_bouton = MLV_load_font("ressources/ARCADE_N.TTF", 20);
  int reussi =0;
  int save = 0;
  int mx;
  int my;
  int i=1;
  int quit = 0;
  while (i==1){
    afficher_pause(font_titre, font_bouton);
    
    if (reussi == 1){
      MLV_draw_text_with_font(300+3, 400, "Sauvegarde Reussie", font_bouton, MLV_COLOR_BLACK);
      MLV_draw_text_with_font(300, 400, "Sauvegarde Reussie", font_bouton, MLV_rgba(184, 134, 11, 255));
      MLV_actualise_window();
    }
    
    MLV_wait_mouse(&mx,&my);
    
    if (clic_bouton(375,675,250,50,mx,my)){
      animation_clic_bouton(375, 675, 250, 50, "Quitter", font_bouton);
      i--;
      quit = 1;
    }
    
    if (clic_bouton(375,600,250,50,mx,my)){
      animation_clic_bouton(375, 600, 250, 50, "Reprendre", font_bouton);
      i=0;
    }

    if (clic_bouton(375,525,250,50,mx,my)){
      animation_clic_bouton(375, 525, 250, 50, "Sauvegarder", font_bouton);
      if (num_sauvegarde == 0){
	save = boucle_choisir_save(font_titre, font_bouton); /* sauvegarde choisie par le joueur*/
      } else {
	save = num_sauvegarde;
      }
      sauvegarder(plateau, longueur, coordonnees, save, nb_pomme, chrono, score, coef, bonus); /* sauvegarde la partie*/
      reussi = 1;
    }
    
  }
  return quit;
}
