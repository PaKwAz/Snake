#ifndef FCT_MENU_H
#define FCT_MENU_H

#include <MLV/MLV_all.h>

void creer_bouton(int x, int y, int width, int height, char* texte, 
                  MLV_Color couleur_fond, MLV_Color couleur_texte, MLV_Font* font);

void animation_clic_bouton(int x, int y, int width, int height, char* texte, MLV_Font* font);

int clic_bouton(int bx, int by, int bw, int bh, int mx, int my);

void afficher_menu(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

void afficher_menu_cote(int score, int meilleur[10]);

void afficher_chrono(float chrono);

void afficher_erreur_sauvegarde(int y, MLV_Font* font_bouton);
  
void afficher_continuer(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

int boucle_menu();

void boucle_commandes(MLV_Font* font_bouton, MLV_Font* font_titre, MLV_Image* commandes);

void boucle_bonus(MLV_Font* font_bouton, MLV_Font* font_titre, MLV_Image* fond_bonus);

int boucle_continuer(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

int boucle_nouvelle();

#endif
