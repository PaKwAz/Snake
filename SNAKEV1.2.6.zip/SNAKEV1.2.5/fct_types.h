#ifndef _FCT_TYPES_H_
#define _FCT_TYPES_H_

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>

#define taille_meilleur 10
#define taille_max 19

typedef struct{
    int serpent;
    int compteur;
    int direction;
} cases;

void test_toutes_les_images();

void tenir_a_j_liste(int coordonnees[361][2], int xtete, int ytete, int longueur);

void ajouter_liste(int coordonnees[361][2], int x, int y, int longueur);

void afficher_image(MLV_Image* image, int x, int y, int hauteur);

void spawn_random(cases plateau[taille_max][taille_max], int hauteur);

void redessiner_arriere_plan(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur);

void affichage_train(cases plateau[taille_max][taille_max], int coordonnees[361][2], int *longueur, int hauteur, float pourcentage, int direction_tete, int anc_queue_x, int anc_queue_y);

void affichage_jeu(int x, int y, int hauteur, MLV_Color couleur, int transformer_x_y);

void spawn_pomme(cases plateau[taille_max][taille_max], int hauteur);

void init_plat(cases plateau[taille_max][taille_max], int *xtete, int *ytete, int save);

void affichage_initial(cases plateau[taille_max][taille_max], int coordonnees[361][2], int longueur, int hauteur, int pomme);

void avancer_tete(cases plateau[taille_max][taille_max], int xtete, int ytete, int longueur, int direction);

int get_scores( int meilleur[taille_meilleur]);

void ecrire_res( int meilleur[taille_meilleur]);

void ajouter_au_buffer(int nouvelle_dir, int direction_actuelle);

void actualiser_direction_depuis_buffer(int *direction);

int gestion_controles(cases plateau[taille_max][taille_max], int coordonnees[361][2], int *longueur, int hauteur, int direction_actuelle, int num_sauvegarde, int nb_pommes, float *chrono, float *temps_en_moins, int score, float coef, int bonus);

void calculer_position_future(int xtete, int ytete, int direction, int *futur_x, int *futur_y);

void recoler_tout(cases plateau[taille_max][taille_max], int longueur, int coordonnees[361][2], int hauteur);

void verifier_interaction_case(cases plateau[taille_max][taille_max], int futur_x, int futur_y, int hauteur, int *pafini, int *a_mange, int *nbpomme, int *longueur, float *coef, int *divise, int coordonnees[361][2], int *bonus);

void deplacer_serpent(cases plateau[taille_max][taille_max], int coordonnees[361][2], int xtete, int ytete, int futur_x, int futur_y, int *longueur, int a_mange, int direction, int hauteur);

void mettre_a_jour_scores(int score, int meilleur[taille_meilleur], int nouvelle_liste[taille_meilleur]);

int main_jeu(int hauteur, int save);

#endif
