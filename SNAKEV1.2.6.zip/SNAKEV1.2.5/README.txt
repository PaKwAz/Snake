================================================================================
				SNAKE GAME
================================================================================

Un jeu type Snake développé en C avec la bibliothèque MLV.

================================================================================
PRÉREQUIS
================================================================================

- GCC (compilateur C)
- Make
- Bibliothèque MLV installée

================================================================================
COMPILATION ET EXÉCUTION
================================================================================

COMPILATION
-----------
Pour compiler le jeu, ouvrez un terminal dans le répertoire du projet et 
exécutez :

    make

Cette commande générera l'exécutable du jeu.


LANCEMENT DU JEU
----------------
Une fois la compilation terminée, lancez le jeu avec :

    ./snake


================================================================================
COMMENT JOUER
================================================================================

- Flèches directionnelles : Déplacer le serpent
- Échap : Ouvrir le menu de pause


================================================================================
SYSTÈME DE SAUVEGARDE
================================================================================

SAUVEGARDER UNE PARTIE
----------------------
1. Appuyez sur Échap pendant le jeu pour mettre en pause
2. Choisissez l'option de sauvegarde
3. Sélectionnez l'un des 4 slots de sauvegarde disponibles (1, 2, 3 ou 4)

CONTINUER UNE PARTIE
----------------------
1. Dans le menu appuyez sur "CONTINUER"
2. Sélectionnez l'un des 4 slots de sauvegarde (1, 2, 3 ou 4)

FICHIERS DE SAUVEGARDE
----------------------
Une fois la partie sauvegardée, un fichier "save{1,2,3,4}" sera créé dans le 
dossier du jeu.

================================================================================
STRUCTURE DES FICHIERS SAUVEGARDE
================================================================================

LIGNES
----------------------
1. Longueur n de la liste des coordonnées du serpent
   n suivantes. (x serpent) (y serpent) (tête?) (compteur) (direction)
2. nbr éléments spéciaux (pommes, bonus, cactus, wagons)
   n suivantes. (x) (y) (compteur) (direction)
3. nbr pommes mangées
4. chrono partie
5. score
6. coef pour calcul score
7. bonus ajouté au score

================================================================================
STRUCTURE DES FICHIERS
================================================================================

FICHIERS SOURCES (.c)
---------------------
Les fichiers C contiennent le code source du jeu :

- functions_jeu.c        : Fonctions principales du jeu
- functions_menu.c       : Gestion des menus
- functions_pause.c      : Système de pause
- functions_perdu.c      : Écran de fin de partie
- functions_sauvegarde.c : Système de sauvegarde/chargement
- main.c                 : Main du jeu


FICHIERS D'EN-TÊTE (.h)
-----------------------
Les fichiers header définissent les structures et fonctions :

- fct_menu.h
- fct_pause.h
- fct_perdu.h
- fct_sauvegarde.h
- fct_types.h

DOSSIER "ressources/"
---------------------
Contient toutes les ressources du jeu :

- cactus.png          
- charbon.png       
- fond.png         
- fond_bonus.png    
- locomotive_d.png
- locomotive_b.png
- locomotive_g.png
- locomotive_h.png
- wagon.png      
- wagon_cote.png    
- random.png  
- commandes.png       
- ARCADE_N.TTF          


FICHIER "Makefile"
------------------
Configure la compilation du projet avec toutes les dépendances nécessaires.


================================================================================
				Bon jeu !
================================================================================
