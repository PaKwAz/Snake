#include "fct_sauvegarde.h"
#include "fct_types.h"
#include <stdio.h>
#include <stdlib.h>

int lire_sauvegarde(cases plateau[taille_max][taille_max], int *longueur, int coordonnees [361][2], int num_sauvegarde, int *nb_pommes, float *chrono, int *score, float *coef, int *bonus){
    FILE* save;
    int i, x, y, len, ret = 0;
    int nb_objets, type_obj;
    char nom_fichier[20];
    int direction;

    sprintf(nom_fichier, "save%d.txt", num_sauvegarde);
    save = fopen(nom_fichier, "r");

    if (save == NULL) return 0;

    if (fscanf(save, "%d", &len) != 1) { 
        fclose(save); 
        return 0; 
    }
    *longueur = len;

    for ( i = 0 ; i < len ; i ++ ){
        fscanf(save, "%d %d", &x, &y);
        
        if (x >= 0 && x < taille_max && y >= 0 && y < taille_max) {
            coordonnees[i][0] = x;
            coordonnees[i][1] = y;
            fscanf(save, "%d %d %d", &plateau[x][y].serpent, &plateau[x][y].compteur, &plateau[x][y].direction);
        } else {
            int poubelle;
            fscanf(save, "%d %d %d", &poubelle, &poubelle, &poubelle);
        }
    }

    if (fscanf(save, "%d", &nb_objets) == 1) {
        for (i = 0; i < nb_objets; i++) {
            fscanf(save, "%d %d %d %d", &x, &y, &type_obj, &direction);
            if (x >= 0 && x < taille_max && y >= 0 && y < taille_max) {
                plateau[x][y].compteur = type_obj; 
                plateau[x][y].serpent = 0;
                plateau[x][y].direction = direction;
            }
        }
        ret = 1;
    }

    fscanf(save, "%d", nb_pommes);
    fscanf(save, "%f", chrono);
    fscanf(save, "%d", score);
    fscanf(save, "%f", coef);
    fscanf(save, "%d", bonus);

    fclose(save);
    return ret;
}

void sauvegarder(cases plateau[taille_max][taille_max], int longueur, int coordonnees [361][2], int num_sauvegarde, int nb_pommes, float chrono, int score, float coef, int bonus){
    FILE* save;
    int i, j, x, y;
    int compteur_objets = 0;
    char nom_fichier[20];
    
    sprintf(nom_fichier, "save%d.txt", num_sauvegarde);
    save = fopen(nom_fichier, "w");

    if (save == NULL) {
        perror("Erreur sauvegarde");
        exit(EXIT_FAILURE);
    }

    fprintf(save,"%d\n", longueur);

    for ( i = 0 ; i < longueur ; i ++){
        x = coordonnees[i][0];
        y = coordonnees[i][1];
        fprintf(save, "%d %d %d %d %d\n", x, y, plateau[x][y].serpent, plateau[x][y].compteur, plateau[x][y].direction);
    }

    for (i = 0; i < taille_max; i++) {
        for (j = 0; j < taille_max; j++) {
            if (plateau[i][j].compteur < 0) {
                compteur_objets++;
            }
        }
    }
    fprintf(save, "%d\n", compteur_objets);

    for (i = 0; i < taille_max; i++) {
        for (j = 0; j < taille_max; j++) {
            if (plateau[i][j].compteur < 0) {
                fprintf(save, "%d %d %d %d\n", i, j, plateau[i][j].compteur, plateau[i][j].direction);
            }
        }
    }

    fprintf(save,"%d\n", nb_pommes);
    fprintf(save,"%f\n", chrono);
    fprintf(save, "%d\n", score);
    fprintf(save, "%f\n", coef);
    fprintf(save, "%d\n", bonus);

    fclose(save);
}