#include <stdio.h>
#include <stdlib.h>
#include <MLV/MLV_all.h>
#include "fct_menu.h"
#include "fct_pause.h"

void afficher_pause(MLV_Font* font_titre, MLV_Font* font_bouton, int*score){
  MLV_Color  couleur_fond = MLV_rgba(218, 165, 32, 255);
  MLV_Color  couleur_texte = MLV_rgba(255, 248, 220, 255);
  MLV_draw_filled_rectangle(250, 250, 500, 500, couleur_fond);
  MLV_draw_rectangle(250, 250, 500, 500, couleur_texte);
  creer_bouton(375, 675, 250, 50, "Reprendre", couleur_fond, couleur_texte, font_bouton);
  creer_bouton(375, 600, 250, 50, "Quitter", couleur_fond, couleur_texte, font_bouton);

  MLV_actualise_window();
}

int boucle_pause(int * score){
  MLV_Font* font_titre = MLV_load_font("assets/ARCADE_N.TTF", 100);
  MLV_Font* font_bouton = MLV_load_font("assets/ARCADE_N.TTF", 20);
  int mx;
  int my;
  int i=1;
  afficher_pause(font_titre, font_bouton, score);
  while (i==1){
    MLV_wait_mouse(&mx,&my);
    if (clic_bouton(375,675,250,50,mx,my)){
      animation_clic_bouton(375, 675, 250, 50, "Reprendre", font_bouton);
      i=0;
    }
    if (clic_bouton(375,600,250,50,mx,my)){
      animation_clic_bouton(375, 600, 250, 50, "Quitter", font_bouton);
      return 1;
    }
  }
  return 0;
}
