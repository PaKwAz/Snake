#ifndef FCT_MENU_H
#define FCT_MENU_H

#include <MLV/MLV_all.h>

/* Crée et dessine un bouton avec texte centré */
void creer_bouton(int x, int y, int width, int height, char* texte, 
                  MLV_Color couleur_fond, MLV_Color couleur_texte, MLV_Font* font);

/* Animation lors du clic sur un bouton */
void animation_clic_bouton(int x, int y, int width, int height, char* texte, MLV_Font* font);

/* Vérifie si un clic est dans la zone d'un bouton */
int clic_bouton(int bx, int by, int bw, int bh, int mx, int my);

/* Affiche le menu principal */
void afficher_menu(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

/* Affiche le panneau latéral avec le score */
void afficher_menu_cote(int *score);

/* Affiche le menu pour continuer une partie */
void afficher_continuer(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

/* Affiche le menu pour créer une nouvelle partie */
void afficher_nouvelle(MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

/* Affiche l'écran du mode 2 joueurs */
void afficher_2joueurs();

/* Affiche l'écran des commandes */
void afficher_commandes(MLV_Font* font_titre, MLV_Font* font_texte);

/* Boucle principale du menu */
int boucle_menu(int width, int height);

/* Boucle du menu continuer */
int boucle_continuer(int width, int height, MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

/* Boucle du menu nouvelle partie */
int boucle_nouvelle(int width, int height, MLV_Font* font_titre, MLV_Font* font_bouton, MLV_Image* fond);

/* Boucle du mode 2 joueurs */
void boucle_2joueurs(int width, int height);

/* Boucle du menu commandes */
int boucle_commandes(int width, int height, MLV_Font* font_titre, MLV_Font* font_bouton);

#endif
