#ifndef FCT_SAUVEGARDE_H
#define FCT_SAUVEGARDE_H

#include "fct_types.h"

/* Fonction pour lire une sauvegarde et restaurer l'état du jeu */
int lire_sauvegarde(cases plateau[taille_max][taille_max], int *longueur, int coordonnees [361][2], int num_sauvegarde, int *nb_pommes, float *chrono, int *score, float *coef, int *bonus);

/* Fonction pour écrire l'état actuel du jeu dans un fichier */
void sauvegarder(cases plateau[taille_max][taille_max], int longueur, int coordonnees [361][2], int num_sauvegarde, int nb_pommes, float chrono, int score, float coef, int bonus);

#endif

    